class Section {
  final int? id;
  final String name;
  final int semesterId;

  Section({
    this.id,
    required this.name,
    required this.semesterId,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'semesterId': semesterId,
    };
  }

  factory Section.fromMap(Map<String, dynamic> map) {
    return Section(
      id: map['id'],
      name: map['name'],
      semesterId: map['semesterId'],
    );
  }
}
class Room {
  final int? id;
  final String name;
  final String building;
  final int capacity;

  Room({
    this.id,
    required this.name,
    required this.building,
    required this.capacity,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'building': building,
      'capacity': capacity,
    };
  }

  factory Room.fromMap(Map<String, dynamic> map) {
    return Room(
      id: map['id'],
      name: map['name'],
      building: map['building'],
      capacity: map['capacity'],
    );
  }
}

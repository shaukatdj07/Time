import 'package:flutter/material.dart';

class ClassSchedule {
  final int? id;
  final int teacherId;
  final int roomId;
  final int sectionId;
  final String courseName;
  final String day; // 'Monday', 'Tuesday', etc.
  final TimeOfDay startTime;
  final TimeOfDay endTime;

  ClassSchedule({
    this.id,
    required this.teacherId,
    required this.roomId,
    required this.sectionId,
    required this.courseName,
    required this.day,
    required this.startTime,
    required this.endTime,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'teacherId': teacherId,
      'roomId': roomId,
      'sectionId': sectionId,
      'courseName': courseName,
      'day': day,
      'startTime': '${startTime.hour}:${startTime.minute}',
      'endTime': '${endTime.hour}:${endTime.minute}',
    };
  }

  factory ClassSchedule.fromMap(Map<String, dynamic> map) {
    final startParts = (map['startTime'] as String).split(':');
    final endParts = (map['endTime'] as String).split(':');

    return ClassSchedule(
      id: map['id'],
      teacherId: map['teacherId'],
      roomId: map['roomId'],
      sectionId: map['sectionId'],
      courseName: map['courseName'],
      day: map['day'],
      startTime: TimeOfDay(
        hour: int.parse(startParts[0]),
        minute: int.parse(startParts[1]),
      ),
      endTime: TimeOfDay(
        hour: int.parse(endParts[0]),
        minute: int.parse(endParts[1]),
      ),
    );
  }
}
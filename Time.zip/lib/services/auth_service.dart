import 'package:flutter/material.dart';
import '../models/user.dart';
import '../services/database_helper.dart'; // ✅ Ensure correct path

class AuthService with ChangeNotifier {
  User? _currentUser;

  User? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get isCoordinator => _currentUser?.role == 'coordinator';
  bool get isTeacher => _currentUser?.role == 'teacher';
  bool get isStudent => _currentUser?.role == 'student';

  static final DatabaseHelper _dbHelper = DatabaseHelper.instance; // ✅ Correct way to create an instance

  Future<bool> login(String email, String password) async {
    final user = await _dbHelper.getUser(email, password);
    if (user != null) {
      _currentUser = user;
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}

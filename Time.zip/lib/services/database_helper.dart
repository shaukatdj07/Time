import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/department.dart';
import '../../models/room.dart';
import '../../models/teacher.dart';
import '../../models/semester.dart';
import '../../models/section.dart';
import '../../models/class_schedule.dart';
import '../../models/user.dart';
import 'package:flutter/material.dart'; // Add this import for TimeOfDay

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();

  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('timetable.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    // Users table
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role TEXT NOT NULL
      )
    ''');

    // Departments table
    await db.execute('''
      CREATE TABLE departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL UNIQUE
      )
    ''');

    // Teachers table
    await db.execute('''
      CREATE TABLE teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        departmentId INTEGER NOT NULL,
        FOREIGN KEY (departmentId) REFERENCES departments (id) ON DELETE CASCADE
      )
    ''');

    // Rooms table
    await db.execute('''
      CREATE TABLE rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        building TEXT NOT NULL,
        capacity INTEGER NOT NULL
      )
    ''');

    // Semesters table
    await db.execute('''
      CREATE TABLE semesters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        startDate TEXT NOT NULL,
        endDate TEXT NOT NULL
      )
    ''');

    // Sections table
    await db.execute('''
      CREATE TABLE sections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        semesterId INTEGER NOT NULL,
        FOREIGN KEY (semesterId) REFERENCES semesters (id) ON DELETE CASCADE
      )
    ''');

    // Class schedules table
    await db.execute('''
      CREATE TABLE class_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        teacherId INTEGER NOT NULL,
        roomId INTEGER NOT NULL,
        sectionId INTEGER NOT NULL,
        courseName TEXT NOT NULL,
        day TEXT NOT NULL,
        startTime TEXT NOT NULL,
        endTime TEXT NOT NULL,
        FOREIGN KEY (teacherId) REFERENCES teachers (id) ON DELETE CASCADE,
        FOREIGN KEY (roomId) REFERENCES rooms (id) ON DELETE CASCADE,
        FOREIGN KEY (sectionId) REFERENCES sections (id) ON DELETE CASCADE
      )
    ''');

    // Create default admin user
    await db.insert('users', {
      'name': 'Admin',
      'email': 'admin@edu.com',
      'password': 'admin123', // In real app, hash this password
      'role': 'coordinator',
    });
  }

  // User operations
  Future<User?> getUser(String email, String password) async {
    final db = await instance.database;

    print("Looking up user with email: $email and password: $password");

    final maps = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );

    print("Query result: ${maps.length}");

    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    } else {
      return null;
    }
  }

  // Department operations
  Future<int> insertDepartment(Department department) async {
    final db = await database;
    return await db.insert('departments', department.toMap());
  }

  Future<int> updateDepartment(Department department) async {
    final db = await database;
    return await db.update(
      'departments',
      department.toMap(),
      where: 'id = ?',
      whereArgs: [department.id],
    );
  }

  Future<List<Department>> getAllDepartments() async {
    final db = await database;
    final result = await db.query('departments');
    return result.map((map) => Department.fromMap(map)).toList();
  }

  Future<int> deleteDepartment(int id) async {
    final db = await database;
    return await db.delete('departments', where: 'id = ?', whereArgs: [id]);
  }

  // Teacher operations
  Future<int> createTeacher(Teacher teacher) async {
    final db = await instance.database;
    return await db.insert('teachers', teacher.toMap());
  }

  Future<List<Teacher>> getAllTeachers() async {
    final db = await instance.database;
    final result = await db.query('teachers');
    return result.map((map) => Teacher.fromMap(map)).toList();
  }

  Future<int> updateTeacher(Teacher teacher) async {
    final db = await instance.database;
    return await db.update(
      'teachers',
      teacher.toMap(),
      where: 'id = ?',
      whereArgs: [teacher.id],
    );
  }

  Future<int> deleteTeacher(int id) async {
    final db = await instance.database;
    return await db.delete('teachers', where: 'id = ?', whereArgs: [id]);
  }

  // Room operations
  Future<int> createRoom(Room room) async {
    final db = await instance.database;
    return await db.insert('rooms', room.toMap());
  }

  Future<List<Room>> getAllRooms() async {
    final db = await instance.database;
    final result = await db.query('rooms');
    return result.map((map) => Room.fromMap(map)).toList();
  }

  Future<int> updateRoom(Room room) async {
    final db = await instance.database;
    return await db.update(
      'rooms',
      room.toMap(),
      where: 'id = ?',
      whereArgs: [room.id],
    );
  }

  Future<int> deleteRoom(int id) async {
    final db = await instance.database;
    return await db.delete('rooms', where: 'id = ?', whereArgs: [id]);
  }

  // Semester operations
  Future<int> createSemester(Semester semester) async {
    final db = await instance.database;
    return await db.insert('semesters', semester.toMap());
  }

  Future<List<Semester>> getAllSemesters() async {
    final db = await instance.database;
    final result = await db.query('semesters');
    return result.map((map) => Semester.fromMap(map)).toList();
  }

  Future<int> updateSemester(Semester semester) async {
    final db = await instance.database;
    return await db.update(
      'semesters',
      semester.toMap(),
      where: 'id = ?',
      whereArgs: [semester.id],
    );
  }

  Future<int> deleteSemester(int id) async {
    final db = await instance.database;
    return await db.delete('semesters', where: 'id = ?', whereArgs: [id]);
  }

  // Section operations
  Future<int> createSection(Section section) async {
    final db = await instance.database;
    return await db.insert('sections', section.toMap());
  }

  Future<List<Section>> getAllSections() async {
    final db = await instance.database;
    final result = await db.query('sections');
    return result.map((map) => Section.fromMap(map)).toList();
  }

  Future<List<Section>> getSectionsBySemester(int semesterId) async {
    final db = await instance.database;
    final result = await db.query(
      'sections',
      where: 'semesterId = ?',
      whereArgs: [semesterId],
    );
    return result.map((map) => Section.fromMap(map)).toList();
  }

  Future<int> updateSection(Section section) async {
    final db = await instance.database;
    return await db.update(
      'sections',
      section.toMap(),
      where: 'id = ?',
      whereArgs: [section.id],
    );
  }

  Future<int> deleteSection(int id) async {
    final db = await instance.database;
    return await db.delete('sections', where: 'id = ?', whereArgs: [id]);
  }

  // Class Schedule operations
  Future<int> createClassSchedule(ClassSchedule schedule) async {
    final db = await instance.database;

    // Format times for database query
    final startTimeStr = schedule.startTime.toDatabaseString();
    final endTimeStr = schedule.endTime.toDatabaseString();

    // Check for conflicts
    final conflicts = await db.query(
      'class_schedules',
      where: '''
      (roomId = ? OR teacherId = ? OR sectionId = ?) AND 
      day = ? AND 
      (
        (startTime <= ? AND endTime > ?) OR
        (startTime < ? AND endTime >= ?) OR
        (startTime >= ? AND endTime <= ?)
      )
    ''',
      whereArgs: [
        schedule.roomId,
        schedule.teacherId,
        schedule.sectionId,
        schedule.day,
        startTimeStr,
        startTimeStr,
        endTimeStr,
        endTimeStr,
        startTimeStr,
        endTimeStr,
      ],
    );

    if (conflicts.isNotEmpty) {
      throw Exception('Schedule conflict detected');
    }

    return await db.insert('class_schedules', schedule.toMap());
  }

  Future<List<ClassSchedule>> getAllClassSchedules() async {
    final db = await instance.database;
    final result = await db.query('class_schedules');
    return result.map((map) => ClassSchedule.fromMap(map)).toList();
  }

  Future<List<ClassSchedule>> getClassSchedulesForSection(int sectionId) async {
    final db = await instance.database;
    final result = await db.query(
      'class_schedules',
      where: 'sectionId = ?',
      whereArgs: [sectionId],
    );
    return result.map((map) => ClassSchedule.fromMap(map)).toList();
  }

  Future<int> deleteClassSchedule(int id) async {
    final db = await instance.database;
    return await db.delete('class_schedules', where: 'id = ?', whereArgs: [id]);
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}

extension TimeOfDayExtension on TimeOfDay {
  String toDatabaseString() {
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }
}
import 'package:flutter/material.dart';
import '../../../models/section.dart';
import '../../../services/database_helper.dart';

class SectionFormScreen extends StatefulWidget {
  final Section? section;
  final int semesterId;

  const SectionFormScreen({
    super.key,
    this.section,
    required this.semesterId,
  });

  @override
  _SectionFormScreenState createState() => _SectionFormScreenState();
}

class _SectionFormScreenState extends State<SectionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.section != null) {
      _nameController.text = widget.section!.name;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _saveSection() async {
    if (!_formKey.currentState!.validate()) return;

    final section = Section(
      id: widget.section?.id,
      name: _nameController.text.trim(),
      semesterId: widget.semesterId,
    );

    try {
      if (widget.section == null) {
        await DatabaseHelper.instance.createSection(section);
      } else {
        await DatabaseHelper.instance.updateSection(section);
      }
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving section: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.section == null ? 'Add Section' : 'Edit Section'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Section Name',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter section name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveSection,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
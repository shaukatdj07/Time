import 'package:flutter/material.dart';
import 'package:time/screens/coordinator/sections/add_edit_section.dart';
import '../../../models/section.dart';
import '../../../models/semester.dart';
import '../../../services/database_helper.dart';


class SectionListScreen extends StatefulWidget {
  const SectionListScreen({super.key});

  @override
  _SectionListScreenState createState() => _SectionListScreenState();
}

class _SectionListScreenState extends State<SectionListScreen> {
  late Future<List<Semester>> _semestersFuture;
  int? _selectedSemesterId;
  late Future<List<Section>> _sectionsFuture;

  @override
  void initState() {
    super.initState();
    _semestersFuture = DatabaseHelper.instance.getAllSemesters();
    _refreshSections();
  }

  Future<void> _refreshSections() async {
    setState(() {
      if (_selectedSemesterId != null) {
        _sectionsFuture = DatabaseHelper.instance.getSectionsBySemester(_selectedSemesterId!);
      } else {
        _sectionsFuture = Future.value([]);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sections'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              if (_selectedSemesterId == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please select a semester first')),
                );
                return;
              }

              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SectionFormScreen(
                    semesterId: _selectedSemesterId!,
                  ),
                ),
              );
              _refreshSections();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          FutureBuilder<List<Semester>>(
            future: _semestersFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const LinearProgressIndicator();
              } else if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Text('No semesters found');
              }

              final semesters = snapshot.data!;
              if (_selectedSemesterId == null) {
                _selectedSemesterId = semesters.first.id;
                _refreshSections();
              }

              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButton<int>(
                  value: _selectedSemesterId,
                  items: semesters.map((semester) {
                    return DropdownMenuItem<int>(
                      value: semester.id,
                      child: Text(semester.name),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedSemesterId = value;
                      _refreshSections();
                    });
                  },
                  isExpanded: true,
                ),
              );
            },
          ),
          Expanded(
            child: FutureBuilder<List<Section>>(
              future: _sectionsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('No sections found for selected semester'));
                }

                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    final section = snapshot.data![index];
                    return ListTile(
                      title: Text(section.name),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => SectionFormScreen(
                                    section: section,
                                    semesterId: _selectedSemesterId!,
                                  ),
                                ),
                              );
                              _refreshSections();
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () async {
                              await _deleteSection(section.id!);
                            },
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSection(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'),
        content: const Text('Are you sure you want to delete this section?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await DatabaseHelper.instance.deleteSection(id);
        _refreshSections();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Section deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting section: $e')),
        );
      }
    }
  }
}
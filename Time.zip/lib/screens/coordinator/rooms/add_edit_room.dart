import 'package:flutter/material.dart';
import '../../../models/room.dart';
import '../../../services/database_helper.dart';

class RoomFormScreen extends StatefulWidget {
  final Room? room;

  const RoomFormScreen({super.key, this.room});

  @override
  _RoomFormScreenState createState() => _RoomFormScreenState();
}

class _RoomFormScreenState extends State<RoomFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _buildingController = TextEditingController();
  final _capacityController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.room != null) {
      _nameController.text = widget.room!.name;
      _buildingController.text = widget.room!.building;
      _capacityController.text = widget.room!.capacity.toString();
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _buildingController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  Future<void> _saveRoom() async {
    if (!_formKey.currentState!.validate()) return;

    final room = Room(
      id: widget.room?.id,
      name: _nameController.text.trim(),
      building: _buildingController.text.trim(),
      capacity: int.tryParse(_capacityController.text.trim()) ?? 0,
    );

    try {
      if (widget.room == null) {
        await DatabaseHelper.instance.createRoom(room);
      } else {
        await DatabaseHelper.instance.updateRoom(room);
      }
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving room: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.room == null ? 'Add Room' : 'Edit Room'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Room Name',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter room name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _buildingController,
                decoration: const InputDecoration(
                  labelText: 'Building',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter building name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _capacityController,
                decoration: const InputDecoration(
                  labelText: 'Capacity',
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter capacity';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveRoom,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
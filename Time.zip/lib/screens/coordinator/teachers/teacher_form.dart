import 'package:flutter/material.dart';
import '../../../models/teacher.dart';
import '../../../models/department.dart';
import '../../../services/database_helper.dart';

class TeacherFormScreen extends StatefulWidget {
  final Teacher? teacher;

  const TeacherFormScreen({super.key, this.teacher});

  @override
  _TeacherFormScreenState createState() => _TeacherFormScreenState();
}

class _TeacherFormScreenState extends State<TeacherFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  int? _selectedDepartmentId;
  late Future<List<Department>> _departmentsFuture;

  @override
  void initState() {
    super.initState();
    _departmentsFuture = DatabaseHelper.instance.getAllDepartments();
    if (widget.teacher != null) {
      _nameController.text = widget.teacher!.name;
      _emailController.text = widget.teacher!.email;
      _selectedDepartmentId = widget.teacher!.departmentId;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _saveTeacher() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedDepartmentId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a department')),
      );
      return;
    }

    final teacher = Teacher(
      id: widget.teacher?.id,
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      departmentId: _selectedDepartmentId!,
    );

    try {
      if (widget.teacher == null) {
        await DatabaseHelper.instance.createTeacher(teacher);
      } else {
        await DatabaseHelper.instance.updateTeacher(teacher);
      }
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving teacher: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.teacher == null ? 'Add Teacher' : 'Edit Teacher'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Teacher Name',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter teacher name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                ),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter email';
                  }
                  if (!value.contains('@')) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              FutureBuilder<List<Department>>(
                future: _departmentsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Text('No departments found');
                  }

                  final departments = snapshot.data!;
                  if (_selectedDepartmentId == null && widget.teacher == null) {
                    _selectedDepartmentId = departments.first.id;
                  }

                  return DropdownButtonFormField<int>(
                    value: _selectedDepartmentId,
                    items: departments.map((department) {
                      return DropdownMenuItem<int>(
                        value: department.id,
                        child: Text('${department.name} (${department.code})'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedDepartmentId = value;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Department',
                    ),
                    validator: (value) {
                      if (value == null) {
                        return 'Please select a department';
                      }
                      return null;
                    },
                  );
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveTeacher,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
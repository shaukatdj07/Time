import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/teacher.dart';
import '../../../models/department.dart';
import '../../../services/database_helper.dart';
import 'teacher_form.dart';

class TeacherListScreen extends StatefulWidget {
  const TeacherListScreen({super.key});

  @override
  _TeacherListScreenState createState() => _TeacherListScreenState();
}

class _TeacherListScreenState extends State<TeacherListScreen> {
  late Future<List<Teacher>> _teachersFuture;
  late Future<List<Department>> _departmentsFuture;

  @override
  void initState() {
    super.initState();
    _refreshTeachers();
    _departmentsFuture = DatabaseHelper.instance.getAllDepartments();
  }

  Future<void> _refreshTeachers() async {
    setState(() {
      _teachersFuture = DatabaseHelper.instance.getAllTeachers();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teachers'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const TeacherFormScreen(),
                ),
              );
              _refreshTeachers();
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Teacher>>(
        future: _teachersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No teachers found'));
          }

          return FutureBuilder<List<Department>>(
            future: _departmentsFuture,
            builder: (context, deptSnapshot) {
              if (deptSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (deptSnapshot.hasError) {
                return Center(child: Text('Error: ${deptSnapshot.error}'));
              }

              final departments = deptSnapshot.data ?? [];

              return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final teacher = snapshot.data![index];
                  final department = departments.firstWhere(
                        (dept) => dept.id == teacher.departmentId,
                    orElse: () => Department(id: -1, name: 'Unknown', code: 'UNK'),
                  );

                  return ListTile(
                    title: Text(teacher.name),
                    subtitle: Text('${teacher.email} - ${department.name}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => TeacherFormScreen(
                                  teacher: teacher,
                                ),
                              ),
                            );
                            _refreshTeachers();
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () async {
                            await _deleteTeacher(teacher.id!);
                          },
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _deleteTeacher(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'),
        content: const Text('Are you sure you want to delete this teacher?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await DatabaseHelper.instance.deleteTeacher(id);
        _refreshTeachers();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Teacher deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting teacher: $e')),
        );
      }
    }
  }
}
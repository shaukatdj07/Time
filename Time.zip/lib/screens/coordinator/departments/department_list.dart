// department_form_screen.dart
import 'package:flutter/material.dart';
import '../../../models/department.dart';
import '../../../services/database_helper.dart';

class DepartmentFormScreen extends StatefulWidget {
  final Department? department;

  const DepartmentFormScreen({Key? key, this.department}) : super(key: key);

  @override
  _DepartmentFormScreenState createState() => _DepartmentFormScreenState();
}

class _DepartmentFormScreenState extends State<DepartmentFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _codeController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.department?.name ?? '');
    _codeController = TextEditingController(text: widget.department?.code ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  void _saveDepartment() async {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final code = _codeController.text.trim();

      final department = Department(
        id: widget.department?.id,
        name: name,
        code: code,
      );

      if (widget.department == null) {
        await DatabaseHelper.instance.insertDepartment(department);
      } else {
        await DatabaseHelper.instance.updateDepartment(department);
      }

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.department == null ? 'Add Department' : 'Edit Department'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Department Name'),
                validator: (value) =>
                value!.isEmpty ? 'Please enter department name' : null,
              ),
              TextFormField(
                controller: _codeController,
                decoration: const InputDecoration(labelText: 'Department Code'),
                validator: (value) =>
                value!.isEmpty ? 'Please enter department code' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveDepartment,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

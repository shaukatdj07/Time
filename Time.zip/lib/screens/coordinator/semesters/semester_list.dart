import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:time/screens/coordinator/semesters/add_edit_semester.dart';
import '../../../models/semester.dart';
import '../../../services/database_helper.dart';


class SemesterListScreen extends StatefulWidget {
  const SemesterListScreen({super.key});

  @override
  _SemesterListScreenState createState() => _SemesterListScreenState();
}

class _SemesterListScreenState extends State<SemesterListScreen> {
  late Future<List<Semester>> _semestersFuture;
  final DateFormat _dateFormat = DateFormat('MMM d, yyyy');

  @override
  void initState() {
    super.initState();
    _refreshSemesters();
  }

  Future<void> _refreshSemesters() async {
    setState(() {
      _semestersFuture = DatabaseHelper.instance.getAllSemesters();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Semesters'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SemesterFormScreen(),
                ),
              );
              _refreshSemesters();
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Semester>>(
        future: _semestersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No semesters found'));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final semester = snapshot.data![index];
              return ListTile(
                title: Text(semester.name),
                subtitle: Text(
                    '${_dateFormat.format(semester.startDate)} - ${_dateFormat.format(semester.endDate)}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SemesterFormScreen(
                              semester: semester,
                            ),
                          ),
                        );
                        _refreshSemesters();
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () async {
                        await _deleteSemester(semester.id!);
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _deleteSemester(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'),
        content: const Text('Are you sure you want to delete this semester?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await DatabaseHelper.instance.deleteSemester(id);
        _refreshSemesters();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Semester deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting semester: $e')),
        );
      }
    }
  }
}
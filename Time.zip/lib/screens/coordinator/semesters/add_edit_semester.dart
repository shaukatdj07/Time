import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../models/semester.dart';
import '../../../services/database_helper.dart';

class SemesterFormScreen extends StatefulWidget {
  final Semester? semester;

  const SemesterFormScreen({super.key, this.semester});

  @override
  _SemesterFormScreenState createState() => _SemesterFormScreenState();
}

class _SemesterFormScreenState extends State<SemesterFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void initState() {
    super.initState();
    if (widget.semester != null) {
      _nameController.text = widget.semester!.name;
      _startDate = widget.semester!.startDate;
      _endDate = widget.semester!.endDate;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate ?? (_startDate ?? DateTime.now()).add(const Duration(days: 90)),
      firstDate: _startDate ?? DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _endDate) {
      setState(() {
        _endDate = picked;
      });
    }
  }

  Future<void> _saveSemester() async {
    if (!_formKey.currentState!.validate()) return;
    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select both start and end dates')),
      );
      return;
    }

    final semester = Semester(
      id: widget.semester?.id,
      name: _nameController.text.trim(),
      startDate: _startDate!,
      endDate: _endDate!,
    );

    try {
      if (widget.semester == null) {
        await DatabaseHelper.instance.createSemester(semester);
      } else {
        await DatabaseHelper.instance.updateSemester(semester);
      }
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving semester: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.semester == null ? 'Add Semester' : 'Edit Semester'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Semester Name',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter semester name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              ListTile(
                title: Text(
                  _startDate == null
                      ? 'Select Start Date'
                      : 'Start Date: ${DateFormat('MMM d, yyyy').format(_startDate!)}',
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: () => _selectStartDate(context),
              ),
              ListTile(
                title: Text(
                  _endDate == null
                      ? 'Select End Date'
                      : 'End Date: ${DateFormat('MMM d, yyyy').format(_endDate!)}',
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: () => _selectEndDate(context),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveSemester,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
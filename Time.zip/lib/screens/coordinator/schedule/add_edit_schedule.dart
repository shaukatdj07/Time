import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import '../../../models/class_schedule.dart';
import '../../../models/room.dart';
import '../../../models/section.dart';
import '../../../models/semester.dart';
import '../../../models/teacher.dart';
import '../../../services/database_helper.dart';

class AddEditScheduleScreen extends StatefulWidget {
  final ClassSchedule? schedule;
  final int? sectionId;

  const AddEditScheduleScreen({
    super.key,
    this.schedule,
    this.sectionId,
  });

  @override
  _AddEditScheduleScreenState createState() => _AddEditScheduleScreenState();
}

class _AddEditScheduleScreenState extends State<AddEditScheduleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _courseNameController = TextEditingController();
  String? _selectedDay;
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  int? _selectedTeacherId;
  int? _selectedRoomId;
  int? _selectedSectionId;

  late Future<List<Teacher>> _teachersFuture;
  late Future<List<Room>> _roomsFuture;
  late Future<List<Semester>> _semestersFuture;
  late Future<List<Section>> _sectionsFuture;

  final List<String> _days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  @override
  void initState() {
    super.initState();
    _teachersFuture = DatabaseHelper.instance.getAllTeachers();
    _roomsFuture = DatabaseHelper.instance.getAllRooms();
    _semestersFuture = DatabaseHelper.instance.getAllSemesters();

    if (widget.schedule != null) {
      _courseNameController.text = widget.schedule!.courseName;
      _selectedDay = widget.schedule!.day;
      _startTime = widget.schedule!.startTime;
      _endTime = widget.schedule!.endTime;
      _selectedTeacherId = widget.schedule!.teacherId;
      _selectedRoomId = widget.schedule!.roomId;
      _selectedSectionId = widget.schedule!.sectionId;
    } else if (widget.sectionId != null) {
      _selectedSectionId = widget.sectionId;
    }

    _sectionsFuture = DatabaseHelper.instance.getAllSections();
  }

  @override
  void dispose() {
    _courseNameController.dispose();
    super.dispose();
  }

  Future<void> _selectStartTime(BuildContext context) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _startTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _startTime) {
      setState(() {
        _startTime = picked;
        // If end time is before start time or not set, adjust it
        if (_endTime == null || _endTime!.hour < picked.hour ||
            (_endTime!.hour == picked.hour && _endTime!.minute <= picked.minute)) {
          _endTime = TimeOfDay(hour: picked.hour + 1, minute: picked.minute);
        }
      });
    }
  }

  Future<void> _selectEndTime(BuildContext context) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _endTime ?? (_startTime ?? TimeOfDay.now()).replacing(
        hour: (_startTime ?? TimeOfDay.now()).hour + 1,
      ),
    );
    if (picked != null && picked != _endTime) {
      // Validate end time is after start time
      if (_startTime == null ||
          picked.hour > _startTime!.hour ||
          (picked.hour == _startTime!.hour && picked.minute > _startTime!.minute)) {
        setState(() {
          _endTime = picked;
        });
      } else {
        Fluttertoast.showToast(
          msg: "End time must be after start time",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }

  Future<void> _saveSchedule() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedDay == null ||
        _startTime == null ||
        _endTime == null ||
        _selectedTeacherId == null ||
        _selectedRoomId == null ||
        _selectedSectionId == null) {
      Fluttertoast.showToast(
        msg: "Please fill all fields",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    final schedule = ClassSchedule(
      id: widget.schedule?.id,
      teacherId: _selectedTeacherId!,
      roomId: _selectedRoomId!,
      sectionId: _selectedSectionId!,
      courseName: _courseNameController.text.trim(),
      day: _selectedDay!,
      startTime: _startTime!,
      endTime: _endTime!,
    );

    try {
      if (widget.schedule == null) {
        await DatabaseHelper.instance.createClassSchedule(schedule);
      } else {
        // For update, we should first delete the old one and then insert new
        // to properly handle conflict detection
        await DatabaseHelper.instance.deleteClassSchedule(widget.schedule!.id!);
        await DatabaseHelper.instance.createClassSchedule(schedule);
      }
      Navigator.pop(context, true); // Return true to indicate success
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Error: $e",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      // If it was an update, we need to restore the original schedule
      if (widget.schedule != null) {
        try {
          await DatabaseHelper.instance.createClassSchedule(widget.schedule!);
        } catch (e) {
          // Ignore this error as we're already handling an error
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.schedule == null ? 'Add Schedule' : 'Edit Schedule'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _courseNameController,
                decoration: const InputDecoration(
                  labelText: 'Course Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter course name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedDay,
                items: _days.map((day) {
                  return DropdownMenuItem<String>(
                    value: day,
                    child: Text(day),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedDay = value;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Day',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null) {
                    return 'Please select a day';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ListTile(
                      title: Text(
                        _startTime == null
                            ? 'Select Start Time'
                            : _startTime!.format(context),
                      ),
                      trailing: const Icon(Icons.access_time),
                      onTap: () => _selectStartTime(context),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ListTile(
                      title: Text(
                        _endTime == null
                            ? 'Select End Time'
                            : _endTime!.format(context),
                      ),
                      trailing: const Icon(Icons.access_time),
                      onTap: () => _selectEndTime(context),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              FutureBuilder<List<Teacher>>(
                future: _teachersFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Text('No teachers found');
                  }

                  final teachers = snapshot.data!;
                  if (_selectedTeacherId == null && teachers.isNotEmpty) {
                    _selectedTeacherId = teachers.first.id;
                  }

                  return DropdownButtonFormField<int>(
                    value: _selectedTeacherId,
                    items: teachers.map((teacher) {
                      return DropdownMenuItem<int>(
                        value: teacher.id,
                        child: Text(teacher.name),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedTeacherId = value;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Teacher',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null) {
                        return 'Please select a teacher';
                      }
                      return null;
                    },
                  );
                },
              ),
              const SizedBox(height: 16),
              FutureBuilder<List<Room>>(
                future: _roomsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Text('No rooms found');
                  }

                  final rooms = snapshot.data!;
                  if (_selectedRoomId == null && rooms.isNotEmpty) {
                    _selectedRoomId = rooms.first.id;
                  }

                  return DropdownButtonFormField<int>(
                    value: _selectedRoomId,
                    items: rooms.map((room) {
                      return DropdownMenuItem<int>(
                        value: room.id,
                        child: Text('${room.name} (${room.building})'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedRoomId = value;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Room',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null) {
                        return 'Please select a room';
                      }
                      return null;
                    },
                  );
                },
              ),
              const SizedBox(height: 16),
              FutureBuilder<List<Semester>>(
                future: _semestersFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Text('No semesters found');
                  }

                  final semesters = snapshot.data!;
                  return FutureBuilder<List<Section>>(
                    future: _sectionsFuture,
                    builder: (context, sectionSnapshot) {
                      if (sectionSnapshot.connectionState == ConnectionState.waiting) {
                        return const CircularProgressIndicator();
                      } else if (sectionSnapshot.hasError) {
                        return Text('Error: ${sectionSnapshot.error}');
                      } else if (!sectionSnapshot.hasData || sectionSnapshot.data!.isEmpty) {
                        return const Text('No sections found');
                      }

                      final sections = sectionSnapshot.data!;
                      if (_selectedSectionId == null && sections.isNotEmpty) {
                        _selectedSectionId = sections.first.id;
                      }

                      return DropdownButtonFormField<int>(
                        value: _selectedSectionId,
                        items: sections.map((section) {
                          final semester = semesters.firstWhere(
                                (s) => s.id == section.semesterId,
                            orElse: () => Semester(
                              id: -1,
                              name: 'Unknown',
                              startDate: DateTime.now(),
                              endDate: DateTime.now(),
                            ),
                          );
                          return DropdownMenuItem<int>(
                            value: section.id,
                            child: Text('${section.name} (${semester.name})'),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedSectionId = value;
                          });
                        },
                        decoration: const InputDecoration(
                          labelText: 'Section',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null) {
                            return 'Please select a section';
                          }
                          return null;
                        },
                      );
                    },
                  );
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _saveSchedule,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Save Schedule'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../../models/class_schedule.dart';
import '../../../../models/room.dart';
import '../../../../models/teacher.dart';
import '../../../../models/section.dart';
import '../../../../services/database_helper.dart';
import 'add_edit_schedule.dart';

class ScheduleListScreen extends StatelessWidget {
  const ScheduleListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final db = Provider.of<DatabaseHelper>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Class Schedule'),
      ),
      body: FutureBuilder<List<ClassSchedule>>(
        future: db.getAllClassSchedules(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No schedules found'));
          }

          final schedules = snapshot.data!;

          return ListView.builder(
            itemCount: schedules.length,
            itemBuilder: (context, index) {
              final schedule = schedules[index];
              return FutureBuilder(
                future: Future.wait([
                  db.getAllTeachers(),
                  db.getAllRooms(),
                  db.getAllSections(),
                ]),
                builder: (context, AsyncSnapshot<List<dynamic>> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text('Loading...'),
                    );
                  }

                  final teachers = snapshot.data![0] as List<Teacher>;
                  final rooms = snapshot.data![1] as List<Room>;
                  final sections = snapshot.data![2] as List<Section>;

                  final teacher = teachers.firstWhere(
                        (t) => t.id == schedule.teacherId,
                    orElse: () => Teacher(
                      id: -1,
                      name: 'Unknown',
                      email: '',
                      departmentId: -1,
                    ),
                  );

                  final room = rooms.firstWhere(
                        (r) => r.id == schedule.roomId,
                    orElse: () => Room(
                      id: -1,
                      name: 'Unknown',
                      building: '',
                      capacity: 0,
                    ),
                  );

                  final section = sections.firstWhere(
                        (s) => s.id == schedule.sectionId,
                    orElse: () => Section(
                      id: -1,
                      name: 'Unknown',
                      semesterId: -1,
                    ),
                  );

                  return ListTile(
                    title: Text(schedule.courseName),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Teacher: ${teacher.name}'),
                        Text('Room: ${room.name}'),
                        Text('Section: ${section.name}'),
                        Text('Day: ${_getDayName(schedule.day)}'),
                        Text(
                          'Time: ${schedule.startTime.hour.toString().padLeft(2, '0')}:${schedule.startTime.minute.toString().padLeft(2, '0')} - '
                              '${schedule.endTime.hour.toString().padLeft(2, '0')}:${schedule.endTime.minute.toString().padLeft(2, '0')}',
                        ),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AddEditScheduleScreen(
                                  schedule: schedule,
                                ),
                              ),
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () async {
                            await db.deleteClassSchedule(schedule.id!);
                          },
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AddEditScheduleScreen(),
            ),
          );
        },
      ),
    );
  }

  String _getDayName(String day) {
    switch (day.toLowerCase()) {
      case 'monday': return 'Monday';
      case 'tuesday': return 'Tuesday';
      case 'wednesday': return 'Wednesday';
      case 'thursday': return 'Thursday';
      case 'friday': return 'Friday';
      case 'saturday': return 'Saturday';
      case 'sunday': return 'Sunday';
      default: return day;
    }
  }
}
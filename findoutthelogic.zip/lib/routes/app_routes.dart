// class AppRoutes {
//   static const String login = '/login';
//   static const String dashboard = '/dashboard';
//   static const String room = '/room';
//   static const String department = '/department';
//   static const String teachers = '/teachers';
//   static const String timetable = '/timetable';
//   static const String settings = '/settings';
// }
export 'package:cloud_firestore/cloud_firestore.dart';
export 'package:flutter/material.dart';
export 'package:get/get.dart';
export 'package:timetable_management/models/room_model.dart';

export 'package:timetable_management/controllers/timetable_controller.dart';
export 'package:timetable_management/models/department_model.dart';

export 'package:timetable_management/models/time_table_model.dart';

export 'package:timetable_management/screens/timetable/widgets/day_selector.dart';
export 'package:timetable_management/screens/timetable/widgets/department_info.dart';
export 'package:timetable_management/screens/timetable/widgets/filter_section.dart';
export 'package:timetable_management/screens/timetable/widgets/timetable_view.dart';

export 'package:timetable_management/screens/department/department_widgets.dart';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:timetable_management/models/department_model.dart';

class DepartmentController extends GetxController {
  var departments = <Department>[].obs;
  var isLoading = true.obs;
  var selectedDepartment =
      Rx<Department?>(null); // Define reactive selectedDepartment

  @override
  void onInit() {
    super.onInit();
    fetchDepartments(); // Fetch data when the controller is initialized
  }

  // Fetch departments from Firebase
  Future<void> fetchDepartments() async {
    try {
      isLoading(true); // Set loading to true before fetching data
      var snapshot =
          await FirebaseFirestore.instance.collection('departments').get();

      // Parse the departments and store them in the list
      departments.value = snapshot.docs
          .map((doc) => Department.fromMap(doc.id, doc.data()))
          .toList();
    } catch (e) {
      log('Error fetching departments: $e');
    } finally {
      isLoading(false); // Set loading to false after fetching
    }
  }

  // Set selected department
  void setSelectedDepartment(Department department) {
    selectedDepartment.value = department; // Update selected department
  }

  // Add a new department with 8 semesters
  Future<void> addDepartment(String departmentName) async {
    try {
      // Create a new document reference
      final docRef = FirebaseFirestore.instance.collection('departments').doc();

      // Create a new department with Firestore's document ID
      final newDepartment = Department(
        id: docRef.id, // Use Firestore's generated ID
        name: departmentName,
        semesters: List.generate(
          8,
          (index) => Semester(semesterNumber: index + 1, sections: []),
        ),
      );

      // Save the department in Firestore with its correct ID
      await docRef.set(newDepartment.toMap());

      // Add the new department to the local list
      departments.add(newDepartment);
    } catch (e) {
      log('Error adding department: $e');
    }
  }
  
  // Add a section to a semester in a department
  Future<void> addSectionToSemester(
      String departmentId, int semester, String sectionName) async {
    try {
      log('Adding section to semester $semester in department $departmentId');
      final department =
          departments.firstWhere((dept) => dept.id == departmentId);

      final semesterIndex = department.semesters
          .indexWhere((sem) => sem.semesterNumber == semester);

      if (semesterIndex != -1) {
        department.semesters[semesterIndex].sections.add(sectionName);
        update(); // Notify listeners
      }

      // Update department in Firestore
      await _updateDepartmentInFirebase(department);

      // Optionally, you can call fetchDepartments to refresh after adding a section
      // fetchDepartments(); // Uncomment this if you want to refetch departments from Firestore
    } catch (e) {
      print('Error adding section to semester: $e');
    }
  }

  // Remove a section from a semester in a department
  Future<void> removeSectionFromSemester(
      String departmentId, int semester, String sectionName) async {
    try {
      log('Removing section $sectionName from semester $semester in department $departmentId');
      
      // Find the department by ID
      final departmentIndex = departments.indexWhere((dept) => dept.id == departmentId);
      
      if (departmentIndex != -1) {
        // Find the semester by number
        final semesterIndex = departments[departmentIndex].semesters
            .indexWhere((sem) => sem.semesterNumber == semester);
        
        if (semesterIndex != -1) {
          // Remove the section from the sections list
          departments[departmentIndex].semesters[semesterIndex].sections
              .remove(sectionName);
          
          // Create a copy of the department to ensure reactivity in GetX
          final updatedDepartment = Department(
            id: departments[departmentIndex].id,
            name: departments[departmentIndex].name,
            semesters: List.from(departments[departmentIndex].semesters),
          );
          
          // Update the department in the local list
          departments[departmentIndex] = updatedDepartment;
          
          // Update in Firestore
          await _updateDepartmentInFirebase(updatedDepartment);
          
          // Refresh the UI
          departments.refresh();
        }
      }
    } catch (e) {
      print('Error removing section from semester: $e');
    }
  }

  // Update department data in Firestore
  Future<void> _updateDepartmentInFirebase(Department department) async {
    try {
      await FirebaseFirestore.instance
          .collection('departments')
          .doc(department.id)
          .update(department.toMap());
    } catch (e) {
      print('Error updating department in Firebase: $e');
    }
  }

  // Delete department
  Future<void> deleteDepartment(String departmentId) async {
    try {
      // Remove the department from the local list
      departments.removeWhere((dept) => dept.id == departmentId);

      // Delete from Firestore
      await FirebaseFirestore.instance
          .collection('departments')
          .doc(departmentId)
          .delete();
    } catch (e) {
      print('Error deleting department: $e');
    }
  }
}
import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/controllers/department_controller.dart';
import 'package:timetable_management/controllers/room_controller.dart';
import 'package:timetable_management/controllers/teacher_controller.dart';
import 'package:timetable_management/models/teacher_model.dart';
import 'package:timetable_management/models/time_table_model.dart';

class TimetableController extends GetxController {
  final RoomController roomController = Get.find();
  final TeacherController teacherController = Get.find();
  final DepartmentController departmentController = Get.find();

  var timeSlots = <TimeSlot>[].obs;
  var isLoading = false.obs;
  var selectedDay = 'Monday'.obs;
  var selectedStartTime = ''.obs;
  var selectedEndTime = ''.obs;
  var selectedSemester = Rx<int?>(null);
  var selectedSection = Rx<String?>(null);
  var selectedTeacher = Rx<Teacher?>(null);
  var selectedRoom = Rx<Room?>(null);
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<String> weekDays = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];

  @override
  void onInit() {
    super.onInit();
    fetchTimeSlots();
  }

  // Add the missing getFilteredTimeSlots method
  List<TimeSlot> getFilteredTimeSlots() {
    return timeSlots.where((slot) {
      // First filter by selected day
      bool matchesDay = slot.day == selectedDay.value;
      if (!matchesDay) return false;

      // Filter by selected teacher if one is selected
      bool teacherMatches = selectedTeacher.value == null ||
          slot.teacherId == selectedTeacher.value?.id;

      // Filter by selected room if one is selected
      bool roomMatches =
          selectedRoom.value == null || slot.roomId == selectedRoom.value?.id;

      // Filter by selected semester and section if they are selected
      bool semesterMatches = selectedSemester.value == null ||
          slot.semester == selectedSemester.value;

      bool sectionMatches = selectedSection.value == null ||
          slot.section == selectedSection.value;

      // Filter by department if one is selected
      bool departmentMatches =
          departmentController.selectedDepartment.value == null ||
              slot.departmentId ==
                  departmentController.selectedDepartment.value?.id;

      return matchesDay &&
          teacherMatches &&
          roomMatches &&
          semesterMatches &&
          sectionMatches &&
          departmentMatches;
    }).toList();
  }

  Future<bool> isSlotAvailable(
    String roomId,
    String teacherId,
    String day,
    String startTime,
    String endTime,
  ) async {
    try {
      // Convert times to comparable format (24-hour)
      final start = TimeOfDay(
        hour: int.parse(startTime.split(':')[0]),
        minute: int.parse(startTime.split(':')[1]),
      );
      final end = TimeOfDay(
        hour: int.parse(endTime.split(':')[0]),
        minute: int.parse(endTime.split(':')[1]),
      );

      // Check for conflicts in existing time slots
      final conflictingSlots = timeSlots.where((slot) {
        if (slot.day != day) return false;

        final slotStart = TimeOfDay(
          hour: int.parse(slot.startTime.split(':')[0]),
          minute: int.parse(slot.startTime.split(':')[1]),
        );
        final slotEnd = TimeOfDay(
          hour: int.parse(slot.endTime.split(':')[0]),
          minute: int.parse(slot.endTime.split(':')[1]),
        );

        // Convert to minutes for easier comparison
        final startMinutes = start.hour * 60 + start.minute;
        final endMinutes = end.hour * 60 + end.minute;
        final slotStartMinutes = slotStart.hour * 60 + slotStart.minute;
        final slotEndMinutes = slotEnd.hour * 60 + slotEnd.minute;

        // Check if times overlap
        bool timeOverlap =
            !(endMinutes <= slotStartMinutes || startMinutes >= slotEndMinutes);

        // Check if either the room or teacher is already booked
        return timeOverlap &&
            (slot.roomId == roomId || slot.teacherId == teacherId);
      });

      if (conflictingSlots.isNotEmpty) {
        String conflictMessage = '';
        for (var slot in conflictingSlots) {
          if (slot.roomId == roomId) {
            conflictMessage +=
                'Room is already booked from ${slot.startTime} to ${slot.endTime}\n';
          }
          if (slot.teacherId == teacherId) {
            conflictMessage +=
                'Teacher has another class from ${slot.startTime} to ${slot.endTime}\n';
          }
        }
        Get.snackbar(
          'Scheduling Conflict',
          conflictMessage,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          duration: const Duration(seconds: 5),
        );
        return false;
      }

      return true;
    } catch (e) {
      print('Error checking slot availability: $e');
      return false;
    }
  }

  void resetSelections() {
    selectedTeacher.value = null;
    selectedRoom.value = null;
    resetSemesterAndSection();
  }

  void resetSemesterAndSection() {
    selectedSemester.value = null;
    selectedSection.value = null;
  }

  List<int> getAvailableSemesters() {
    if (departmentController.selectedDepartment.value == null) return [];
    return List.generate(
      departmentController.selectedDepartment.value!.semesters.length,
      (index) => index + 1,
    );
  }

  List<String> getAvailableSections() {
    if (departmentController.selectedDepartment.value == null ||
        selectedSemester.value == null) return [];

    final semester = departmentController.selectedDepartment.value!.semesters
        .firstWhere((sem) => sem.semesterNumber == selectedSemester.value);
    return semester.sections;
  }

  Future<void> fetchTimeSlots() async {
    try {
      isLoading(true);
      final snapshot = await _firestore.collection('timeSlots').get();
      timeSlots.assignAll(
        snapshot.docs
            .map((doc) => TimeSlot.fromMap(doc.id, doc.data()))
            .toList(),
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to fetch time slots: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }

  Future<void> addTimeSlot({
    required String startTime,
    required String endTime,
    required String teacherId,
    required String roomId,
    required String departmentId,
    required int semester,
    required String section,
    required String subject,
  }) async {
    try {
      isLoading(true);

      // Check if the room and teacher are available at this time
      if (!await isSlotAvailable(
          roomId, teacherId, selectedDay.value, startTime, endTime)) {
        Get.snackbar(
          'Error',
          'Selected room or teacher is not available at this time',
          backgroundColor: Colors.redAccent,
          colorText: Colors.white,
        );
        return;
      }

      final timeSlot = TimeSlot(
        id: '',
        day: selectedDay.value,
        startTime: startTime,
        endTime: endTime,
        teacherId: teacherId,
        roomId: roomId,
        departmentId: departmentId,
        semester: semester,
        section: section,
        subject: subject,
      );

      final docRef =
          await _firestore.collection('timeSlots').add(timeSlot.toMap());
      timeSlots.add(TimeSlot.fromMap(docRef.id, timeSlot.toMap()));
      Get.back();
      Get.snackbar(
        'Success',
        'Time slot added successfully',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to add time slot: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteTimeSlot(String timeSlotId) async {
    try {
      isLoading(true);
      await _firestore.collection('timeSlots').doc(timeSlotId).delete();
      timeSlots.removeWhere((slot) => slot.id == timeSlotId);
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to delete time slot: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }
}

import 'dart:developer';
import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/models/teacher_model.dart';

class TeacherController extends GetxController {
  // RxList to hold teachers fetched from Firebase
  var teachers = <Teacher>[].obs;
  var isLoading = false.obs;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void onInit() {
    super.onInit();
    fetchTeachers(); // Automatically fetch teachers when the controller is initialized
  }

  // Fetch teachers from Firebase
  Future<void> fetchTeachers() async {
    try {
      isLoading(true);
      QuerySnapshot snapshot = await _firestore.collection('teachers').get();
      teachers.assignAll(
        snapshot.docs
            .map((doc) => Teacher.fromMap(doc.data() as Map<String, dynamic>, doc.id))
            .toList(),
      );
    } catch (e) {
      log("Error fetching teachers: $e");
      Get.snackbar(
        'Error',
        'Failed to fetch teachers: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }

  // Add a new teacher to Firebase
  Future<void> addTeacher(Teacher teacher) async {
    try {
      isLoading(true);
      DocumentReference docRef =
          await _firestore.collection('teachers').add(teacher.toMap());
      
      // Optionally, update the list after adding
      teachers.add(teacher.copyWith(id: docRef.id));
    } catch (e) {
      log("Error adding teacher: $e");
      Get.snackbar(
        'Error',
        'Failed to add teacher: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }

  // Delete a teacher from Firebase
  Future<void> deleteTeacher(String id) async {
    try {
      isLoading(true);
      await _firestore.collection('teachers').doc(id).delete();
      teachers.removeWhere((teacher) => teacher.id == id);
    } catch (e) {
      log("Error deleting teacher: $e");
      Get.snackbar(
        'Error',
        'Failed to delete teacher: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }
}

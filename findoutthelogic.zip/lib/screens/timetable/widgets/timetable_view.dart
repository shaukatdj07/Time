import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/screens/timetable/widgets/timetable_table.dart';

import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/screens/timetable/widgets/timetable_table.dart';

class TimetableView extends StatelessWidget {
  final TimetableController controller;

  const TimetableView({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      }

      final department = controller.departmentController.selectedDepartment.value;
      if (department == null) {
        return const Center(child: Text('Please select a department'));
      }

      final sortedSlots = _getSortedSlots();

      if (sortedSlots.isEmpty) {
        return const Center(child: Text('No classes scheduled for this day'));
      }

      return SizedBox(
        height: Get.height - 260,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: sortedSlots.length,
          itemBuilder: (context, index) {
            final slot = sortedSlots[index];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Padding(
                //   padding: const EdgeInsets.all(16),
                //   child: Text(
                //     '${slot.startTime} - Semester ${slot.semester}, Section ${slot.section}',
                //     style: const TextStyle(
                //       fontSize: 18,
                //       fontWeight: FontWeight.bold,
                //     ),
                //   ),
                // ),
                TimetableTable(
                  slots: [slot], // Passing single slot to maintain table format
                  controller: controller,
                ),
                const SizedBox(height: 16),
              ],
            );
          },
        ),
      );
    });
  }

  List<TimeSlot> _getSortedSlots() {
    final department = controller.departmentController.selectedDepartment.value;
    final selectedDay = controller.selectedDay.value;

    if (department == null) return [];

    // Get all slots for the selected department and day
    final departmentSlots = controller.timeSlots
        .where((slot) =>
    slot.departmentId == department.id && slot.day == selectedDay)
        .toList();

    // Sort slots by start time
    departmentSlots.sort((a, b) => a.startTime.compareTo(b.startTime));

    return departmentSlots;
  }
}


class SlotGroup {
  final int semester;
  final String section;
  final List<TimeSlot> slots;

  SlotGroup({
    required this.semester,
    required this.section,
    required this.slots,
  });
}

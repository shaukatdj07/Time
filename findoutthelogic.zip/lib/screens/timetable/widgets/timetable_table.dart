import 'package:intl/intl.dart';
import 'package:timetable_management/const/app_export.dart';


class TimetableTable extends StatelessWidget {
  final List<TimeSlot> slots;
  final TimetableController controller;

  const TimetableTable({
    super.key,
    required this.slots,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Table(
          border: TableBorder.all(
            color: Colors.grey.shade300,
            width: 1,
          ),
          columnWidths: const {
            0: FixedColumnWidth(150), // Time
            1: FixedColumnWidth(150), // Section
            2: FixedColumnWidth(200), // Subject
            3: FixedColumnWidth(200), // Teacher
            4: FixedColumnWidth(150), // Room
            5: FixedColumnWidth(150), // Room
            6: FixedColumnWidth(100), // Actions
          },
          children: [
            _buildHeaderRow(),
            ...slots.map((slot) {
              try {
                return _buildDataRow(slot, context);
              } catch (e) {
                // Return an error row instead of crashing
                return _buildErrorRow(slot, context, e.toString());
              }
            }).toList(),
          ],
        ),
      ),
    );
  }

  TableRow _buildHeaderRow() {
    return TableRow(
      decoration: BoxDecoration(color: Colors.grey.shade100),
      children: [
        'Time',
        'Section',
        'Subject',
        'Teacher',
        'Room',
        'Semester',
        'Actions',
      ].map((header) => TableCell(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Text(
            header,
            style: const TextStyle(fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
      )).toList(),
    );
  }

  TableRow _buildDataRow(TimeSlot slot, BuildContext context) {
    // Safely find teacher or show error
    final teacherName = _getTeacherName(slot.teacherId);
    
    // Safely find room or show error
    final roomNumber = _getRoomNumber(slot.roomId);

    return TableRow(
      children: [
        _buildTableCell(
            '${_formatTime(slot.startTime)} - ${_formatTime(slot.endTime)}'),
        _buildTableCell(slot.section),
        _buildTableCell(slot.subject),
        _buildTableCell(teacherName),
        _buildTableCell(roomNumber),
        _buildTableCell(slot.semester.toString()),
        TableCell(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                onPressed: () => _showDeleteConfirmation(context, slot),
              ),
              if (teacherName.contains('Error') || roomNumber.contains('Error'))
                IconButton(
                  icon: const Icon(Icons.warning, color: Colors.amber, size: 20),
                  onPressed: () => _showErrorDetails(context, slot, teacherName, roomNumber),
                ),
            ],
          ),
        ),
      ],
    );
  }

  TableRow _buildErrorRow(TimeSlot slot, BuildContext context, String errorMessage) {
    return TableRow(
      decoration: BoxDecoration(color: Colors.red.shade50),
      children: [
        _buildTableCell('${_formatTime(slot.startTime)} - ${_formatTime(slot.endTime)}'),
        _buildTableCell(slot.section),
        _buildTableCell(slot.subject),
        _buildTableCell('Error'),
        _buildTableCell('Error'),
        _buildTableCell(slot.semester.toString()),
        TableCell(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                onPressed: () => _showDeleteConfirmation(context, slot),
              ),
              IconButton(
                icon: const Icon(Icons.warning, color: Colors.amber, size: 20),
                onPressed: () => _showErrorMessage(context, errorMessage),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _getTeacherName(String teacherId) {
    try {
      return controller.teacherController.teachers
          .firstWhere((t) => t.id == teacherId)
          .name;
    } catch (e) {
      return 'Error: Teacher not found';
    }
  }

  String _getRoomNumber(String roomId) {
    try {
      return controller.roomController.rooms
          .firstWhere((r) => r.id == roomId)
          .roomNumber;
    } catch (e) {
      return 'Error: Room not found';
    }
  }

  void _showErrorDetails(BuildContext context, TimeSlot slot, String teacherError, String roomError) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Data Error'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Subject: ${slot.subject}'),
            Text('Section: ${slot.section}'),
            const SizedBox(height: 8),
            if (teacherError.contains('Error')) 
              Text(teacherError, style: const TextStyle(color: Colors.red)),
            if (roomError.contains('Error')) 
              Text(roomError, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            const Text('This slot references data that no longer exists. Please edit or delete it.')
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          TextButton(
            onPressed: () {
              controller.deleteTimeSlot(slot.id);
              Navigator.pop(context);
            },
            child: const Text('Delete Slot', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showErrorMessage(BuildContext context, String errorMessage) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(errorMessage),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  String _formatTime(String time) {
    try {
      final timeComponents = time.split(':');
      final hour = int.parse(timeComponents[0]);
      final minute = int.parse(timeComponents[1]);

      final dateTime = DateTime(2024, 1, 1, hour, minute);
      return DateFormat('hh:mm a').format(dateTime);
    } catch (e) {
      return time; // Return original if parsing fails
    }
  }

  Widget _buildTableCell(String text) {
    final isError = text.startsWith('Error:');
    
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: isError ? Colors.red : null,
          fontWeight: isError ? FontWeight.bold : null,
        ),
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, TimeSlot slot) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Time Slot'),
        content: const Text('Are you sure you want to delete this time slot?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              controller.deleteTimeSlot(slot.id);
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
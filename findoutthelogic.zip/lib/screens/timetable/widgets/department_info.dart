import 'package:timetable_management/const/app_export.dart';

class DepartmentInfo extends StatelessWidget {
  final TimetableController controller;

  const DepartmentInfo({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final department = controller.departmentController.selectedDepartment.value;
      final semester = controller.selectedSemester.value;
      final section = controller.selectedSection.value;

      if (department == null) {
        return const Center(
          child: Text('Please select a department to view timetable'),
        );
      }

      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                text: department.name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              if (semester != null) const TextSpan(text: ' • '),
              if (semester != null) TextSpan(text: 'Semester $semester'),
              if (section != null) const TextSpan(text: ' • '),
              if (section != null) TextSpan(text: 'Section $section'),
            ],
          ),
        ),
      );
    });
  }
}
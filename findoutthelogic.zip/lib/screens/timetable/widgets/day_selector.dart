import 'package:timetable_management/const/app_export.dart';

class DaySelector extends StatelessWidget {
  final TimetableController controller;

  const DaySelector({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() => SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: controller.weekDays
                .map(
                  (day) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: () {
                          controller.selectedDay.value = day;
                        },
                        child: Container(
                          width: 110,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: controller.selectedDay.value == day
                                ? Colors.blue
                                : Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            day,
                            style: TextStyle(
                              color: controller.selectedDay.value == day
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                        ),
                      )),
                )
                .toList(),
          ),
        ));
  }
}

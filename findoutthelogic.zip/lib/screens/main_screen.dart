// main_screen.dart
import 'package:flutter/material.dart';
import 'package:sidebarx/sidebarx.dart';
import 'package:timetable_management/widgets/sidebar.dart';
import 'package:timetable_management/screens/classes/rooms_screen.dart';
import 'package:timetable_management/screens/dashboard/dashboard_screen.dart';
import 'package:timetable_management/screens/department/department_screen.dart';
import 'package:timetable_management/screens/teachers/teachers_screen.dart';
import 'package:timetable_management/screens/timetable/timetable_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final _controller = SidebarXController(selectedIndex: 0);
  final _key = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final isSmallScreen = MediaQuery.of(context).size.width < 1200;
        return Scaffold(
          key: _key,
          appBar: isSmallScreen
              ? AppBar(
                  elevation: 0,
                  backgroundColor: const Color(0xFF2C3E50),
                  title: const Text(
                    'Timetable Management',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  leading: IconButton(
                    onPressed: () => _key.currentState?.openDrawer(),
                    icon: const Icon(Icons.menu, color: Colors.white),
                  ),
                )
              : null,
          drawer: ExampleSidebarX(controller: _controller),
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFF5F7FA), Color(0xFFE4E7EB)],
              ),
            ),
            child: Row(
              children: [
                if (!isSmallScreen) ExampleSidebarX(controller: _controller),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: _Screens(controller: _controller),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Screens extends StatelessWidget {
  const _Screens({
    Key? key,
    required this.controller,
  }) : super(key: key);

  final SidebarXController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        switch (controller.selectedIndex) {
          case 0:
            return const DashboardScreen();
          case 1:
            return RoomScreen();
          case 2:
            return const DepartmentScreen();
          case 3:
            return TeachersScreen();
          case 4:
            return TimetableScreen();
          default:
            return Center(
              child: Text(
                'Not found page',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: const Color(0xFF2C3E50),
                  fontWeight: FontWeight.bold,
                ),
              ),
            );
        }
      },
    );
  }
}

import 'package:get/get.dart';
import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/controllers/department_controller.dart';
import 'package:timetable_management/controllers/room_controller.dart';
import 'package:timetable_management/controllers/teacher_controller.dart';

class DashboardController extends GetxController {
  final RoomController roomController = Get.find<RoomController>();
  final DepartmentController departmentController = Get.find<DepartmentController>();
  final TeacherController teacherController = Get.find<TeacherController>();

  // Observable values for dashboard stats
  final RxInt totalRooms = 0.obs;
  final RxInt totalDepartments = 0.obs;
  final RxInt totalTeachers = 0.obs;

  @override
  void onInit() {
    super.onInit();
    updateDashboardStats();
    
    // Listen to changes in the controllers
    ever(roomController.rooms, (_) => updateDashboardStats());
    ever(departmentController.departments, (_) => updateDashboardStats());
    ever(teacherController.teachers, (_) => updateDashboardStats());
  }

  void updateDashboardStats() {
    totalRooms.value = roomController.rooms.length;
    totalDepartments.value = departmentController.departments.length;
    totalTeachers.value = teacherController.teachers.length;
  }
}

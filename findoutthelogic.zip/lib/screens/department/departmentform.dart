import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DepartmentForm extends StatefulWidget {
  const DepartmentForm({super.key});

  @override
  State<DepartmentForm> createState() => _DepartmentFormState();
}

class _DepartmentFormState extends State<DepartmentForm> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController departmentNameController =
      TextEditingController();
  final Map<int, TextEditingController> semesterSectionControllers = {};

  @override
  void initState() {
    super.initState();
    // Initialize section controllers for 8 semesters
    for (int i = 1; i <= 8; i++) {
      semesterSectionControllers[i] = TextEditingController();
    }
  }

  @override
  void dispose() {
    departmentNameController.dispose();
    for (var controller in semesterSectionControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width * 0.4,
      child: Form(
        key: formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: departmentNameController,
                  decoration: const InputDecoration(
                    labelText: 'Department Name',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a department name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                const Text(
                  'Add Sections for Each Semester',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                for (int i = 1; i <= 8; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: TextFormField(
                      controller: semesterSectionControllers[i],
                      decoration: InputDecoration(
                        labelText: 'Semester $i Sections (comma-separated)',
                        border: const OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter sections for Semester $i';
                        }
                        return null;
                      },
                    ),
                  ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      // Extract data for department
                      final departmentName = departmentNameController.text;
                      final Map<int, List<String>> semesters = {};
                      for (int i = 1; i <= 8; i++) {
                        semesters[i] = semesterSectionControllers[i]!
                            .text
                            .split(',')
                            .map((s) => s.trim())
                            .toList();
                      }

                      // Example: Save to Firebase or another action
                      print('Department Name: $departmentName');
                      print('Semesters and Sections: $semesters');

                      // Close dialog
                      Navigator.of(context).pop();
                    }
                  },
                  child: const Text('Add Department'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

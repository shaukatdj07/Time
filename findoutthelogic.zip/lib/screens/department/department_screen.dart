import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/controllers/department_controller.dart';
import 'package:timetable_management/screens/department/semester_list.dart';

class DepartmentScreen extends StatefulWidget {
  const DepartmentScreen({super.key});

  @override
  State<DepartmentScreen> createState() => _DepartmentScreenState();
}

class _DepartmentScreenState extends State<DepartmentScreen> {
  final DepartmentController controller = Get.find();

  @override
  void initState() {
    controller.fetchDepartments();
    super.initState();
  }

  void _showAddDepartmentDialog(BuildContext context) {
    final nameController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AddDepartmentDialog(
        controller: nameController,
        onAdd: () {
          if (nameController.text.isNotEmpty) {
            controller.addDepartment(nameController.text);
            nameController.clear();
            Navigator.pop(context);
          }
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  void _showAddSectionDialog(
      BuildContext context, int semester, String departmentId) {
    final sectionController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AddSectionDialog(
        semester: semester,
        controller: sectionController,
        onAdd: () {
          if (sectionController.text.isNotEmpty) {
            controller.addSectionToSemester(
              departmentId,
              semester,
              sectionController.text,
            );
            sectionController.clear();
            Navigator.pop(context);
            setState(() {});
          }
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  // New method for section removal confirmation dialog
  void _confirmRemoveSection(
      BuildContext context, int semester, String departmentId, String section) {
    showDialog(
      context: context,
      builder: (context) => RemoveSectionDialog(
        sectionName: section,
        semesterNumber: semester,
        onConfirm: () {
          controller.removeSectionFromSemester(departmentId, semester, section);
          Navigator.pop(context);
          setState(() {});
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  void _confirmDelete(BuildContext context, Department department) {
    showDialog(
      context: context,
      builder: (context) => DeleteConfirmationDialog(
        departmentName: department.name,
        onConfirm: () {
          controller.deleteDepartment(department.id);
          Navigator.pop(context);
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFF0F4FF), // Very light lavender/blue
              Color(0xFFD6E4FF), // Soft periwinkle blue
            ],
          ),
          border: Border.all(
            color: Colors.grey.shade400,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(12), // Optional: rounded corners
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF845EC2), Color(0xFF9B89B3)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF845EC2).withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Departments',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          '${controller.departments.length} Departments',
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                    buildAddButton(context, 'Add Department', () {
                      _showAddDepartmentDialog(context);
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Obx(
                  () => controller.isLoading.value
                      ? const Center(child: CircularProgressIndicator())
                      : controller.departments.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text(
                                    'No departments available.',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black54,
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  ElevatedButton.icon(
                                    onPressed: () =>
                                        _showAddDepartmentDialog(context),
                                    icon: const Icon(Icons.add),
                                    label: const Text('Add Department'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blueAccent,
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 20,
                                        vertical: 15,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              itemCount: controller.departments.length,
                              itemBuilder: (context, index) {
                                final department = controller.departments[index];
                                return DepartmentCard(
                                  department: department,
                                  onDelete: (dept) =>
                                      _confirmDelete(context, dept),
                                  onAddSection: (semester, deptId) =>
                                      _showAddSectionDialog(
                                          context, semester, deptId),
                                  onRemoveSection: (semester, deptId, section) =>
                                      _confirmRemoveSection(
                                          context, semester, deptId, section),
                                );
                              },
                            ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
Widget buildAddButton(
    BuildContext context, String title, Function() onPressed, {IconData? icon}) {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      gradient: const LinearGradient(
        colors: [Color(0xFF00B8A9), Color(0xFF0F9B8E)],
      ),
      boxShadow: [
        BoxShadow(
          color: const Color(0xFF00B8A9).withOpacity(0.3),
          blurRadius: 8,
          spreadRadius: 1,
        ),
      ],
    ),
    child: ElevatedButton.icon(
      onPressed: onPressed,
      icon:  Icon(icon??Icons.add),
      label: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(
          horizontal: 30,
          vertical: 20,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    ),
  );
}

// department_card.dart
class DepartmentCard extends StatelessWidget {
  final Department department;
  final Function(Department) onDelete;
  final Function(int, String) onAddSection;
  final Function(int, String, String) onRemoveSection;

  const DepartmentCard({
    super.key,
    required this.department,
    required this.onDelete,
    required this.onAddSection,
    required this.onRemoveSection,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFF0F4FF),
            Color(0xFFD6E4FF),
          ],
        ),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade300, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            spreadRadius: 2,
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          title: Text(
            department.name,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          subtitle: Text(
            '${department.semesters.length} Semesters',
            style: const TextStyle(color: Colors.black54),
          ),
          childrenPadding: const EdgeInsets.all(15),
          children: [
            SemesterList(
              semesters: department.semesters,
              departmentId: department.id,
              onAddSection: onAddSection,
              onRemoveSection: onRemoveSection,
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton.icon(
                onPressed: () => onDelete(department),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                icon: const Icon(Icons.delete),
                label: const Text('Delete Department'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

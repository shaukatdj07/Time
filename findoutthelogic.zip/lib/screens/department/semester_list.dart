import 'package:timetable_management/const/app_export.dart';

class SemesterTile extends StatelessWidget {
  final Semester semester;
  final int semesterNumber;
  final String departmentId;
  final Function(int, String) onAddSection;
  final Function(int, String, String) onRemoveSection;

  const SemesterTile({
    Key? key,
    required this.semester,
    required this.semesterNumber,
    required this.departmentId,
    required this.onAddSection,
    required this.onRemoveSection,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFF7F9FC), Color(0xFFE3E9F0)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade300, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: const Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Semester $semesterNumber',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              ElevatedButton.icon(
                onPressed: () => onAddSection(semesterNumber, departmentId),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Section'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Sections
          if (semester.sections.isNotEmpty)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: semester.sections.map((section) {
                return Chip(
                  label: Text(section),
                  backgroundColor: Colors.blue.shade100,
                  deleteIcon: const Icon(Icons.close, size: 18),
                  onDeleted: () =>
                      onRemoveSection(semesterNumber, departmentId, section),
                );
              }).toList(),
            )
          else
            const Text(
              'No sections added yet.',
              style: TextStyle(color: Colors.grey),
            ),
        ],
      ),
    );
  }
}

class SemesterList extends StatelessWidget {
  final List<Semester> semesters;
  final String departmentId;
  final Function(int, String) onAddSection;
  final Function(int, String, String) onRemoveSection;

  const SemesterList({
    Key? key,
    required this.semesters,
    required this.departmentId,
    required this.onAddSection,
    required this.onRemoveSection,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: semesters.length,
      separatorBuilder: (context, index) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        return SemesterTile(
          semester: semesters[index],
          semesterNumber: index + 1,
          departmentId: departmentId,
          onAddSection: onAddSection,
          onRemoveSection: onRemoveSection,
        );
      },
    );
  }
}

class RemoveSectionDialog extends StatelessWidget {
  final String sectionName;
  final int semesterNumber;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  const RemoveSectionDialog({
    Key? key,
    required this.sectionName,
    required this.semesterNumber,
    required this.onConfirm,
    required this.onCancel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      title: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
          SizedBox(width: 8),
          Text('Remove Section'),
        ],
      ),
      content: Text(
        'Are you sure you want to remove section "$sectionName" from Semester $semesterNumber?',
        style: const TextStyle(fontSize: 15),
      ),
      actions: [
        TextButton(
          onPressed: onCancel,
          child: const Text(
            'Cancel',
            style: TextStyle(
              color: Color(0xFF6C757D),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        ElevatedButton(
          onPressed: onConfirm,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          child: const Text('Remove'),
        ),
      ],
    );
    ;
  }
}
import 'package:flutter/material.dart';

class RoomForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController roomNumberController;
  final TextEditingController capacityController;

  const RoomForm({
    super.key,
    required this.formKey,
    required this.roomNumberController,
    required this.capacityController,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextFormField(
            controller: roomNumberController,
            decoration: const InputDecoration(
              labelText: 'Room Number',
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a room number';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: capacityController,
            decoration: const InputDecoration(
              labelText: 'Capacity',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the room capacity';
              }
              if (int.tryParse(value) == null) {
                return 'Capacity must be a valid number';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                // Example: Save to Firebase or another action
                print('Room Number: ${roomNumberController.text}');
                print('Capacity: ${capacityController.text}');

                // Close dialog
                Navigator.of(context).pop();
              }
            },
            child: const Text('Add Room'),
          ),
        ],
      ),
    );
  }
}

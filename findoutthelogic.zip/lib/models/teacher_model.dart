class Teacher {
  String id;
  String name;

  Teacher({
    required this.id,
    required this.name,
  });

  // Converts Teacher model into a map for Firebase storage
  Map<String, dynamic> toMap() {
    return {
      'name': name,
    };
  }

  // Converts map data from Firebase into Teacher model
  factory Teacher.fromMap(Map<String, dynamic> map, String id) {
    return Teacher(
      id: id,
      name: map['name'],
    );
  }

  // Adds the copyWith method for making copies of the Teacher with modified fields
  Teacher copyWith({
    String? id,
    String? name,
    String? department,
    List<String>? subjects,
  }) {
    return Teacher(
      id: id ?? this.id,
      name: name ?? this.name,
    );
  }
}

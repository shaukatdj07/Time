class TimeSlot {
  final String id;
  final String day;
  final String startTime;
  final String endTime;
  final String teacherId;
  final String roomId;
  final String departmentId;
  final int semester;
  final String section;
  final String subject;

  TimeSlot({
    required this.id,
    required this.day,
    required this.startTime,
    required this.endTime,
    required this.teacherId,
    required this.roomId,
    required this.departmentId,
    required this.semester,
    required this.section,
    required this.subject,
  });

  Map<String, dynamic> toMap() {
    return {
      'day': day,
      'startTime': startTime,
      'endTime': endTime,
      'teacherId': teacherId,
      'roomId': roomId,
      'departmentId': departmentId,
      'semester': semester,
      'section': section,
      'subject': subject,
    };
  }

  factory TimeSlot.fromMap(String id, Map<String, dynamic> map) {
    return TimeSlot(
      id: id,
      day: map['day'],
      startTime: map['startTime'],
      endTime: map['endTime'],
      teacherId: map['teacherId'],
      roomId: map['roomId'],
      departmentId: map['departmentId'],
      semester: map['semester'],
      section: map['section'],
      subject: map['subject'],
    );
  }
}

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'package:timetable_management/controllers/auth_controller.dart';
import 'package:timetable_management/controllers/department_controller.dart';
import 'package:timetable_management/controllers/teacher_controller.dart';
import 'package:timetable_management/firebase_options.dart';
import 'package:timetable_management/routes/app_pages.dart';
import 'package:timetable_management/screens/login_screen.dart';
import 'package:timetable_management/screens/main_screen.dart';

import 'controllers/room_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.windows,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final AuthController authController = Get.put(AuthController());
    final RoomController roomController = Get.put(RoomController()); // Add this
    final DepartmentController departmentController = Get.put(DepartmentController()); // Add this
    final TeacherController teacherController = Get.put(TeacherController()); // Add this

    authController.checkAuthStatus();

    return GetMaterialApp(
      title: 'Time Table Management',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
      ),
      initialRoute: AppRoutes.login, // Define the initial route
      getPages: AppRoutes.routes, // Use routes defined in AppRoutes
      home:FirebaseAuth.instance.currentUser != null
          ?const MainScreen():LoginScreen(),
    );
  }
}

import 'package:get/get.dart';
import 'package:timetable_management/main_binding.dart';
import 'package:timetable_management/screens/login_screen.dart';
import 'package:timetable_management/screens/main_screen.dart';

class AppRoutes {
  static const login = '/login';
  static const main = '/main';

  static final routes = [
    GetPage(name: login, page: () => LoginScreen()),
    GetPage(
      name: main,
      page: () => const MainScreen(),
      binding: MainBindings(),
    ),
  ];
}

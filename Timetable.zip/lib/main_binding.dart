import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/controllers/department_controller.dart';
import 'package:timetable_management/controllers/room_controller.dart';
import 'package:timetable_management/controllers/teacher_controller.dart';

class MainBindings extends Bindings {
  @override
  void dependencies() {
    Get.put(DepartmentController()); // Instantiated immediately
    Get.put(RoomController()); // Instantiated immediately
    Get.put(TeacherController()); // Instantiated immediately
    Get.put(TimetableController()); // Instantiated immediately
  }
}

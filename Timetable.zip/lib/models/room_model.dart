import 'package:cloud_firestore/cloud_firestore.dart';

class Room {
  final String id;
  final String roomNumber;
  final String capacity;
  final bool isLab;

  Room({
    required this.id,
    required this.roomNumber,
    required this.capacity,
    required this.isLab,
  });

  // Convert a document from Firestore into a Room object
  factory Room.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Room(
      id: doc.id,
      roomNumber: data['roomNumber'] ?? '',
      capacity: data['capacity'] ?? '',
      isLab: data['isLab'] ?? false,
    );
  }

  // Convert a Room object to a map to save to Firestore
  Map<String, dynamic> toMap() {
    return {
      'roomNumber': roomNumber,
      'capacity': capacity,
      'isLab': isLab,
    };
  }
}

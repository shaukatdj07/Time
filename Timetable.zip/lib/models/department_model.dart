class Department {
  final String id;
  final String name;
  final List<Semester> semesters;

  Department({
    required this.id,
    required this.name,
    required this.semesters,
  });

  // Convert Department to a Map for saving to Firestore
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'semesters': semesters.map((semester) => semester.toMap()).toList(),
    };
  }

  // Convert Firestore Map to Department object
  factory Department.fromMap(String id, Map<String, dynamic> map) {
    var semestersList = (map['semesters'] as List)
        .map((semester) => Semester.fromMap(semester))
        .toList();

    return Department(
      id: id,
      name: map['name'],
      semesters: semestersList,
    );
  }
}

class Semester {
  final int semesterNumber;
  final List<String> sections;

  Semester({
    required this.semesterNumber,
    required this.sections,
  });

  // Convert Semester to Map
  Map<String, dynamic> toMap() {
    return {
      'semesterNumber': semesterNumber,
      'sections': sections,
    };
  }

  // Convert Firestore Map to Semester object
  factory Semester.fromMap(Map<String, dynamic> map) {
    return Semester(
      semesterNumber: map['semesterNumber'],
      sections: List<String>.from(map['sections']),
    );
  }
}

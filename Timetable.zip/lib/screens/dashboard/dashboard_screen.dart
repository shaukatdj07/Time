import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:timetable_management/screens/dashboard/components/stats_card.dart';
import 'package:timetable_management/screens/dashboard/dashboard_controller.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  final DashboardController controller = Get.put(DashboardController());
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Dashboard',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        content:  Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const CircleAvatar(
                              radius: 40,
                              child: Icon(Icons.person, size: 40),
                            ),
                            SizedBox(height: 16),
                            Text(
                              '${FirebaseAuth.instance?.currentUser!.email
                                }',
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                   child:  const CircleAvatar(child: Icon(Icons.person),) // <-- Replace with your widget
                )

              ],
            ),
            const SizedBox(height: 30),
            Expanded(
              child: GridView.count(
                crossAxisCount:
                    MediaQuery.of(context).size.width > 1200 ? 4 : 2,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
                children: [
                  DashboardCard(
                    title: 'Total Rooms',
                    count: controller.totalRooms.value.toString(),
                    icon: Icons.meeting_room,
                    gradientColors: const [Colors.purple, Colors.deepPurple],
                  ),
                  DashboardCard(
                    title: 'Departments',
                    count: controller.totalDepartments.value.toString(),
                    icon: Icons.business,
                    gradientColors: const [Colors.green, Colors.lightGreen],
                  ),
                  DashboardCard(
                    title: 'Teachers',
                    count: controller.totalTeachers.value.toString(),
                    icon: Icons.people,
                    gradientColors: const [Colors.orange, Colors.red],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

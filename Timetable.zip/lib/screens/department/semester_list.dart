import 'package:timetable_management/const/app_export.dart';

class SemesterList extends StatelessWidget {
  final List<Semester> semesters;
  final String departmentId;
  final Function(int, String) onAddSection;
  final Function(int, String, String) onRemoveSection; // New parameter

  const SemesterList({
    Key? key,
    required this.semesters,
    required this.departmentId,
    required this.onAddSection,
    required this.onRemoveSection, // Add this parameter
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: semesters.length,
      itemBuilder: (context, index) {
        return SemesterTile(
          semester: semesters[index],
          semesterNumber: index + 1,
          departmentId: departmentId,
          onAddSection: onAddSection,
          onRemoveSection: onRemoveSection, // Pass the callback
        );
      },
    );
  }
}

class SemesterTile extends StatelessWidget {
  final Semester semester;
  final int semesterNumber;
  final String departmentId;
  final Function(int, String) onAddSection;
  final Function(int, String, String) onRemoveSection; // New parameter

  const SemesterTile({
    Key? key,
    required this.semester,
    required this.semesterNumber,
    required this.departmentId,
    required this.onAddSection,
    required this.onRemoveSection, // Add this parameter
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: ListTile(
          title: Text(
            'Semester $semesterNumber',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextButton.icon(
                icon: const Icon(Icons.add, color: Colors.blueAccent),
                label: const Text(
                  'Add Section',
                  style: TextStyle(color: Colors.blueAccent),
                ),
                onPressed: () => onAddSection(semesterNumber, departmentId),
              ),
              const SizedBox(width: 10),
              Wrap(
                spacing: 8,
                children: semester.sections
                    .map((section) => Chip(
                          label: Text(section),
                          backgroundColor: Colors.blue.shade50,
                          deleteIcon: const Icon(
                            Icons.close,
                            size: 18,
                          ),
                          onDeleted: () => onRemoveSection(
                              semesterNumber, departmentId, section),
                        ))
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RemoveSectionDialog extends StatelessWidget {
  final String sectionName;
  final int semesterNumber;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  const RemoveSectionDialog({
    Key? key,
    required this.sectionName,
    required this.semesterNumber,
    required this.onConfirm,
    required this.onCancel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      title: const Text('Remove Section'),
      content: Text('Are you sure you want to remove section $sectionName from Semester $semesterNumber?'),
      actions: [
        TextButton(
          onPressed: onCancel,
          child: const Text(
            'Cancel',
            style: TextStyle(
              color: Color(0xFF6C757D),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Colors.redAccent, Colors.red],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.redAccent.withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: onConfirm,
            child: const Text('Remove'),
          ),
        ),
      ],
    );
  }
}
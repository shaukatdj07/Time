import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/screens/timetable/widgets/dropdown_fields.dart';

class FilterSection extends StatelessWidget {
  final TimetableController controller;

  const FilterSection({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Filter Timetable',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: DepartmentDropdown(controller: controller),
            ),
            // const SizedBox(width: 16),
            // Expanded(
            //   child: SemesterDropdown(controller: controller),
            // ),
            // const SizedBox(width: 16),
            // Expanded(
            //   child: SectionDropdown(controller: controller),
            // ),
          ],
        ),
      ],
    );
  }
}

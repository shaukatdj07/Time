import 'package:timetable_management/const/app_export.dart';

class DepartmentDropdown extends StatelessWidget {
  final TimetableController controller;

  const DepartmentDropdown({Key? key, required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final selectedDept =
          controller.departmentController.selectedDepartment.value;
      final departments = controller.departmentController.departments;

      return DropdownButtonFormField<String>(
        value:
            selectedDept?.id, // Use department ID instead of Department object
        decoration: const InputDecoration(
          labelText: 'Department',
          border: OutlineInputBorder(),
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        ),
        items: departments
            .map((dept) => DropdownMenuItem(
                  value: dept.id, // Use department ID as value
                  child: Text(dept.name),
                ))
            .toList(),
        onChanged: (value) {
          if (value != null) {
            // Find the department object by ID and set it
            final selectedDepartment =
                departments.firstWhere((dept) => dept.id == value);
            controller.departmentController
                .setSelectedDepartment(selectedDepartment);
            controller.resetSemesterAndSection();
          }
        },
      );
    });
  }
}

class SemesterDropdown extends StatelessWidget {
  final TimetableController controller;
  const SemesterDropdown({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() => DropdownButtonFormField<int>(
          value: controller.selectedSemester.value,
          decoration: const InputDecoration(
            labelText: 'Semester',
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          ),
          items: controller
              .getAvailableSemesters()
              .map((semester) => DropdownMenuItem(
                    value: semester,
                    child: Text('Semester $semester'),
                  ))
              .toList(),
          onChanged: (value) {
            controller.selectedSemester.value = value;
            controller.selectedSection.value = null;
          },
        ));
  }
}

class SectionDropdown extends StatelessWidget {
  final TimetableController controller;
  const SectionDropdown({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() => DropdownButtonFormField<String>(
          value: controller.selectedSection.value,
          decoration: const InputDecoration(
            labelText: 'Section',
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          ),
          items: controller
              .getAvailableSections()
              .map((section) => DropdownMenuItem(
                    value: section,
                    child: Text('Section $section'),
                  ))
              .toList(),
          onChanged: (value) {
            controller.selectedSection.value = value;
          },
        ));
  }
}

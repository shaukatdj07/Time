import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:file_picker/file_picker.dart';
import 'package:timetable_management/const/app_export.dart';
import 'dart:io';
// import 'package:url_launcher/url_launcher.dart';

class PDFService {
  Future<void> generateAndDownloadTimetablePDF({
    required TimetableController controller,
    required BuildContext context,
  }) async {
    // await _showLoadingDialog();

    try {
      final pdf = await _createPDFDocument(controller);
      final outputFile = await _savePDFFile(controller);

      if (outputFile != null) {
        await _handlePDFSave(pdf, outputFile);
        await _showSuccessMessage(outputFile);
      }
    } finally {
      Get.back(); // Close loading dialog
    }
  }

  Future<void> _showLoadingDialog() async {
    Get.dialog(
      const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Generating PDF...'),
              ],
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  Future<pw.Document> _createPDFDocument(TimetableController controller) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (context) => _buildPDFContent(
          controller,
        ),
      ),
    );

    return pdf;
  }

  pw.Widget _buildPDFContent(
    TimetableController controller,
  ) {
    final department = controller.departmentController.selectedDepartment.value;
    final semester = controller.selectedSemester.value;
    final section = controller.selectedSection.value;

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        _buildPDFHeader(),
        pw.SizedBox(height: 20),
        _buildDepartmentInfo(
          department!,
          semester,
          section,
        ),
        pw.SizedBox(height: 20),
        ...controller.weekDays.map((day) {
          final daySlots = _getFilteredSlots(controller, day);
          if (daySlots.isEmpty) return pw.Container();

          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                day,
                style: pw.TextStyle(
                  font: pw.Font.times(),
                  fontSize: 14,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 10),
              _buildTimeTable(
                controller,
                daySlots,
              ),
              pw.SizedBox(height: 20),
            ],
          );
        }).toList(),
      ],
    );
  }

  pw.Widget _buildPDFHeader() {
    return pw.Header(
      level: 0,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Timetable',
            style: pw.TextStyle(
              font: pw.Font.times(),
              fontSize: 24,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.Text(
            DateTime.now().toString().split(' ')[0],
            style: pw.TextStyle(font: pw.Font.times(), fontSize: 14),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildDepartmentInfo(
    Department department,
    int? semester,
    String? section,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'Department: ${department.name}',
          style: pw.TextStyle(
              font: pw.Font.times(),
              fontSize: 16,
              fontWeight: pw.FontWeight.bold),
        ),
        if (semester != null)
          pw.Text('Semester: $semester',
              style: pw.TextStyle(font: pw.Font.times(), fontSize: 12)),
        if (section != null)
          pw.Text('Section: $section',
              style: pw.TextStyle(font: pw.Font.times(), fontSize: 12)),
      ],
    );
  }

  pw.Widget _buildTimeTable(
    TimetableController controller,
    List<TimeSlot> slots,
  ) {
    return pw.Table(
      border: pw.TableBorder.all(),
      columnWidths: {
        0: const pw.FlexColumnWidth(1.5), // Time
        1: const pw.FlexColumnWidth(2), // Subject
        2: const pw.FlexColumnWidth(1.5), // Teacher
        3: const pw.FlexColumnWidth(1), // Room
        4: const pw.FlexColumnWidth(1.5), // Class Info
      },
      children: [
        _buildTableHeader(),
        ...slots.map((slot) => _buildTableRow(controller, slot)).toList(),
      ],
    );
  }

  pw.TableRow _buildTableHeader() {
    final headers = ['Time', 'Subject', 'Teacher', 'Room', 'Class Info'];
    return pw.TableRow(
      decoration: const pw.BoxDecoration(
        color: PdfColors.grey300,
      ),
      children: headers
          .map((header) => pw.Padding(
                padding: const pw.EdgeInsets.all(8),
                child: pw.Text(
                  header,
                  style: pw.TextStyle(
                       fontWeight: pw.FontWeight.bold),
                ),
              ))
          .toList(),
    );
  }

  pw.TableRow _buildTableRow(TimetableController controller, TimeSlot slot) {
    final teacher = controller.teacherController.teachers
        .firstWhere((t) => t.id == slot.teacherId);
    final room =
        controller.roomController.rooms.firstWhere((r) => r.id == slot.roomId);

    return pw.TableRow(
      children: [
        _buildTableCell('${slot.startTime}\n${slot.endTime}'),
        _buildTableCell(slot.subject),
        _buildTableCell(teacher.name),
        _buildTableCell(room.roomNumber),
        _buildTableCell('Semester ${slot.semester}\nSection ${slot.section}'),
      ],
    );
  }

  pw.Widget _buildTableCell(String text) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
      ),
    );
  }

  List<TimeSlot> _getFilteredSlots(TimetableController controller, String day) {
    final department = controller.departmentController.selectedDepartment.value;
    final semester = controller.selectedSemester.value;
    final section = controller.selectedSection.value;

    return controller.timeSlots
        .where((slot) =>
            slot.departmentId == department?.id &&
            (semester == null || slot.semester == semester) &&
            (section == null || slot.section == section) &&
            slot.day == day)
        .toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  Future<String?> _savePDFFile(TimetableController controller) async {
    final department = controller.departmentController.selectedDepartment.value;
    final semester = controller.selectedSemester.value;
    final section = controller.selectedSection.value;

    return FilePicker.platform.saveFile(
      dialogTitle: 'Save Timetable PDF',
      fileName: 'timetable_${department!.name.toLowerCase()}_'
          '${semester ?? "all"}_${section ?? "all"}'
          '_${DateTime.now().millisecondsSinceEpoch}.pdf',
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
  }

  Future<void> _handlePDFSave(
    pw.Document pdf,
    String outputFile,
  ) async {
    final file = File(outputFile);
    await file.writeAsBytes(await pdf.save());
  }

  Future<void> _showSuccessMessage(
    String outputFile,
  ) async {
    Get.snackbar(
      'Success',
      'Timetable saved successfully',
      backgroundColor: Colors.green,
      colorText: Colors.white,
      duration: const Duration(seconds: 5),
      // mainButton: TextButton(
      //   onPressed: () async {
      //     if (await canLaunch('file:$outputFile')) {
      //       await launch('file:$outputFile');
      //     } else {
      //       Process.run('explorer', [outputFile]);
      //     }
      //   },
      //   child: const Text(
      //     'OPEN',
      //     style: TextStyle(color: Colors.white),
      //   ),
      // ),
    );
  }
}

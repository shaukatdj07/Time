import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:timetable_management/screens/timetable/widgets/day_selector.dart';
import 'package:timetable_management/screens/timetable/widgets/filter_section.dart';
import 'package:timetable_management/screens/timetable/widgets/timetable_view.dart';

import '../../controllers/timetable_controller.dart';
import 'add_slot_dialog.dart';

class TimetableScreen extends StatefulWidget {
  const TimetableScreen({super.key});

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  final TimetableController controller = Get.put(TimetableController());
  final GlobalKey timetableKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF845EC2), Color(0xFF9B89B3)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF845EC2).withOpacity(0.3),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Time Table Management',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.print),
                    onPressed: () => _generateTimetablePDF(),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => AddSlotDialog.show(context, controller),
                  ),
                ],
              ),
            ),
            FilterSection(controller: controller),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DaySelector(controller: controller),
                Expanded(
                  child: TimetableView(controller: controller),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _generateTimetablePDF() async {
    try {
      // Show loading indicator
      Get.dialog(
        const Center(child: CircularProgressIndicator()),
        barrierDismissible: false,
      );

      // Create the PDF document
      final pdf = pw.Document();
      
      // Get current filters and data from the controller
      final currentDay = controller.selectedDay.value;
      final filteredSlots = controller.getFilteredTimeSlots();
      // final timeSlots = controller.timeSlots;
      // Add timetable page
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.undefined.copyWith(
            marginTop: 40,
            marginLeft:40,
            marginRight: 40,
            marginBottom: 40,
          ),
          orientation: pw.PageOrientation.landscape,
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                 pw.Header(
                    level: 0,
                    child: pw.Text(
                      'Timetable Management',
                      style: pw.TextStyle(
                        fontSize: 24,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ),
                 pw.SizedBox(height: 10),
                  pw.Text(
                    'Generated on ${DateTime.now().toString().split(' ')[0]}',
                    style: const pw.TextStyle(fontSize: 14),
                  ),
                  pw.SizedBox(height: 10),
                  pw.Text(
                    'Day: $currentDay',
                    style: const pw.TextStyle(fontSize: 16),
                  ),
                  pw.SizedBox(height: 20),
                  pw.Table(
                    border: pw.TableBorder.all(),
                    children: [
                      // Header row
                      pw.TableRow(
                        decoration: const pw.BoxDecoration(
                          color: PdfColors.grey300,
                        ),
                        children: [
                          pw.Padding(
                            padding: const pw.EdgeInsets.all(8),
                            child: pw.Text(
                              'Time',
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                            ),
                          ),
                          pw.Padding(
                            padding: const pw.EdgeInsets.all(8),
                            child: pw.Text(
                              'Subject',
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                            ),
                          ),
                          
                          pw.Padding(
                            padding: const pw.EdgeInsets.all(8),
                            child: pw.Text(
                              'Room',
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                            ),
                          ),
                          
                          pw.Padding(
                            padding: const pw.EdgeInsets.all(8),
                            child: pw.Text(
                              'Department and Section',
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                            ),
                          ),
                          
                          pw.Padding(
                            padding: const pw.EdgeInsets.all(8),
                            child: pw.Text(
                              'Teacher',
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      // Data rows
                      ...filteredSlots.map((slot) {
                        // Get room name from roomId
                        String roomName = 'N/A';
                        final room = controller.roomController.rooms.firstWhereOrNull(
                          (room) => room.id == slot.roomId
                        );
                        if (room != null) {
                          roomName = room.roomNumber;
                        }
                        
                        // Get teacher name from teacherId
                        String teacherName = 'N/A';
                        final teacher = controller.teacherController.teachers.firstWhereOrNull(
                          (teacher) => teacher.id == slot.teacherId
                        );
                        if (teacher != null) {
                          teacherName = teacher.name;
                        }
                        String departmentName = 'N/A';
                        final department = controller.departmentController.departments.firstWhereOrNull(
                          (department) => department.id == slot.departmentId
                        );
                        if (department != null) {
                          departmentName = department.name;
                        }
                        String sectionName = 'N/A';
                        sectionName = slot.section;
                                            
                        return pw.TableRow(
                          children: [
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text('${slot.startTime} - ${slot.endTime}'),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(slot.subject),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(roomName),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text('$departmentName - $sectionName'),
                            ),
              
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(teacherName),
                            ),
                          ],
                        );
                      }),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      );
      // Save the PDF file
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/timetable_${DateTime.now().millisecondsSinceEpoch}.pdf');
      await file.writeAsBytes(await pdf.save());

      // Close the loading indicator
      Get.back();

      Get.snackbar('Success', 'PDF saved at ${file.path}',
          backgroundColor: Colors.green, colorText: Colors.white);

      OpenFile.open(file.path);
    } catch (e) {
      // Close the loading indicator
      Get.back();
      
      Get.snackbar('Error', 'Failed to generate PDF: $e',
          backgroundColor: Colors.red, colorText: Colors.white);
    }
  }
}
import 'package:timetable_management/const/app_export.dart';
import 'package:timetable_management/models/teacher_model.dart';

class AddSlotDialog {
  static void show(BuildContext context, TimetableController controller) {
    final formKey = GlobalKey<FormState>();
    final startTimeController = TextEditingController();
    final endTimeController = TextEditingController();
    final subjectController = TextEditingController();

    Get.dialog(
      Dialog(
        child: AddSlotForm(
          formKey: formKey,
          startTimeController: startTimeController,
          endTimeController: endTimeController,
          subjectController: subjectController,
          controller: controller,
        ),
      ),
    );
  }
}

class AddSlotForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController startTimeController;
  final TextEditingController endTimeController;
  final TextEditingController subjectController;
  final TimetableController controller;

  const AddSlotForm({
    required this.formKey,
    required this.startTimeController,
    required this.endTimeController,
    required this.subjectController,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.3,
      padding: const EdgeInsets.all(16),
      child: Form(
        key: formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 16),
              _buildTimeSelection(context),
              const SizedBox(height: 16),
              _buildDepartmentSelection(),
              const SizedBox(height: 16),
              _buildSemesterAndSectionSelection(),
              const SizedBox(height: 16),
              _buildTeacherAndRoomSelection(),
              const SizedBox(height: 16),
              _buildSubjectInput(),
              const SizedBox(height: 24),
              _buildSubmitButton(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'Add New Time Slot',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Get.back(),
        ),
      ],
    );
  }

  Widget _buildTimeSelection(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextFormField(
            controller: startTimeController,
            decoration: const InputDecoration(
              labelText: 'Start Time',
              border: OutlineInputBorder(),
            ),
            onTap: () async {
              final time = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (time != null) {
                startTimeController.text =
                    '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
              }
            },
            validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: TextFormField(
            controller: endTimeController,
            decoration: const InputDecoration(
              labelText: 'End Time',
              border: OutlineInputBorder(),
            ),
            onTap: () async {
              final time = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (time != null) {
                endTimeController.text =
                    '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
              }
            },
            validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
          ),
        ),
      ],
    );
  }

  Widget _buildDepartmentSelection() {
    return Obx(() => DropdownButtonFormField<Department>(
          value: controller.departmentController.selectedDepartment.value,
          decoration: const InputDecoration(
            labelText: 'Department',
            border: OutlineInputBorder(),
          ),
          items: controller.departmentController.departments
              .map((dept) => DropdownMenuItem(
                    value: dept,
                    child: Text(dept.name),
                  ))
              .toList(),
          onChanged: (value) {
            controller.departmentController.setSelectedDepartment(value!);
            controller.resetSemesterAndSection();
          },
          validator: (value) => value == null ? 'Required' : null,
        ));
  }

  Widget _buildSemesterAndSectionSelection() {
    return Row(
      children: [
        Expanded(
          child: Obx(() => DropdownButtonFormField<int>(
                value: controller.selectedSemester.value,
                decoration: const InputDecoration(
                  labelText: 'Semester',
                  border: OutlineInputBorder(),
                ),
                items: controller
                    .getAvailableSemesters()
                    .map((semester) => DropdownMenuItem(
                          value: semester,
                          child: Text('Semester $semester'),
                        ))
                    .toList(),
                onChanged: (value) {
                  controller.selectedSemester.value = value;
                  controller.selectedSection.value = null;
                },
                validator: (value) => value == null ? 'Required' : null,
              )),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Obx(() => DropdownButtonFormField<String>(
                value: controller.selectedSection.value,
                decoration: const InputDecoration(
                  labelText: 'Section',
                  border: OutlineInputBorder(),
                ),
                items: controller
                    .getAvailableSections()
                    .map((section) => DropdownMenuItem(
                          value: section,
                          child: Text('Section $section'),
                        ))
                    .toList(),
                onChanged: (value) {
                  controller.selectedSection.value = value;
                },
                validator: (value) => value == null ? 'Required' : null,
              )),
        ),
      ],
    );
  }

  Widget _buildTeacherAndRoomSelection() {
    return Row(
      children: [
        Expanded(
          child: Obx(() => DropdownButtonFormField<Teacher>(
                value: controller.selectedTeacher.value,
                decoration: const InputDecoration(
                  labelText: 'Teacher',
                  border: OutlineInputBorder(),
                ),
                items: controller.teacherController.teachers
                    .map((teacher) => DropdownMenuItem(
                          value: teacher,
                          child: Text(teacher.name),
                        ))
                    .toList(),
                onChanged: (value) {
                  controller.selectedTeacher.value = value;
                },
                validator: (value) => value == null ? 'Required' : null,
              )),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Obx(() => DropdownButtonFormField<Room>(
                value: controller.selectedRoom.value,
                decoration: const InputDecoration(
                  labelText: 'Room',
                  border: OutlineInputBorder(),
                ),
                items: controller.roomController.rooms
                    .map((room) => DropdownMenuItem(
                          value: room,
                          child: Text(room.roomNumber),
                        ))
                    .toList(),
                onChanged: (value) {
                  controller.selectedRoom.value = value;
                },
                validator: (value) => value == null ? 'Required' : null,
              )),
        ),
      ],
    );
  }

  Widget _buildSubjectInput() {
    return TextFormField(
      controller: subjectController,
      decoration: const InputDecoration(
        labelText: 'Subject',
        border: OutlineInputBorder(),
      ),
      validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
    );
  }

  Widget _buildSubmitButton(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: (){
            Get.back();
          },
          child: const Text(
            'Cancel',
            style: TextStyle(
              color: Color(0xFF6C757D),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF845EC2), Color(0xFF9B89B3)],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF845EC2).withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () => _handleSubmit(context),
            child: const Text('Add Time Slot'),
          ),
        ),
      ],
    );
  }

  Future<void> _handleSubmit(BuildContext context) async {
    if (formKey.currentState?.validate() ?? false) {
      final isAvailable = await controller.isSlotAvailable(
        controller.selectedRoom.value!.id,
        controller.selectedTeacher.value!.id,
        controller.selectedDay.value,
        startTimeController.text,
        endTimeController.text,

      );

      if (isAvailable) {
        await controller.addTimeSlot(
          startTime: startTimeController.text,
          endTime: endTimeController.text,
          teacherId: controller.selectedTeacher.value!.id,
          roomId: controller.selectedRoom.value!.id,
          departmentId:
          controller.departmentController.selectedDepartment.value!.id,
          semester: controller.selectedSemester.value!,
          section: controller.selectedSection.value!,
          subject: subjectController.text,
        );

        // ✅ Clear the form fields
        startTimeController.clear();
        endTimeController.clear();
        subjectController.clear();

        controller.selectedSemester.value = null;
        controller.selectedSection.value = null;
        controller.selectedTeacher.value = null;
        controller.selectedRoom.value = null;

        // ✅ Optionally close the dialog after adding
        Get.back();
      }
    }
  }

}

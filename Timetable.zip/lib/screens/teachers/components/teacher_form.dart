import 'package:flutter/material.dart';

class TeacherForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController nameController;
  final TextEditingController subjectsController;

  const TeacherForm({
    super.key,
    required this.formKey,
    required this.nameController,
    required this.subjectsController,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextFormField(
            controller: nameController,
            decoration: const InputDecoration(
              labelText: 'Teacher Name',
              hintText: 'Enter teacher name',
            ),
            validator: (value) =>
                value?.isEmpty ?? true ? 'Please enter teacher name' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: subjectsController,
            decoration: const InputDecoration(
              labelText: 'Subjects',
              hintText: 'Enter subjects (comma separated)',
            ),
            validator: (value) =>
                value?.isEmpty ?? true ? 'Please enter subjects' : null,
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  // Handle form submission
                }
              },
              child: const Text('Save Teacher'),
            ),
          ),
        ],
      ),
    );
  }
}
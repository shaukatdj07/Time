import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:timetable_management/routes/app_pages.dart';

import '../screens/main_screen.dart';

class AuthController extends GetxController {
  final RxBool isLoggedIn = false.obs;
  final RxBool isPasswordHidden = true.obs;

  void togglePasswordVisibility() {
    isPasswordHidden.value = !isPasswordHidden.value;
  }

  Future<void> login(String email, String password) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      isLoggedIn.value = true;
      Get.offNamed(AppRoutes.main); // Navigate to Main Screen using named route
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString(),
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    }
  }

  Future<void> logout() async {
     await FirebaseAuth.instance.signOut();
    isLoggedIn.value = false;
    Get.offAllNamed(AppRoutes.login); // Navigate to Login using named route
  }

  void checkAuthStatus() {
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (user != null) {
        isLoggedIn.value = true;
        Get.offAllNamed(AppRoutes.main); // Navigate to Main Screen
      } else {
        isLoggedIn.value = false;
        Get.offAllNamed(AppRoutes.login); // Navigate to Login Screen
      }
    });
  }
}

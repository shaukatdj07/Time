import 'package:timetable_management/const/app_export.dart';

class RoomController extends GetxController {
  var rooms = <Room>[].obs;
  var isLoading = false.obs;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void onInit() {
    super.onInit();
    fetchRooms(); // Automatically fetch rooms when the controller is initialized
  }

  Future<void> addRoom(String roomNumber, String capacity, bool isLab) async {
    try {
      isLoading(true);

      // 🔍 Check if room already exists
      final querySnapshot = await _firestore
          .collection('rooms')
          .where('roomNumber', isEqualTo: roomNumber)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        Get.snackbar(
          'Duplicate Room',
          'A room with this number already exists.',
          backgroundColor: Colors.orange,
          colorText: Colors.white,
        );
        return;
      }

      // ✅ Add room to Firestore
      DocumentReference docRef = await _firestore.collection('rooms').add({
        'roomNumber': roomNumber,
        'capacity': capacity,
        'isLab': isLab,
      });

      // ✅ Add the room to local state with Firestore docId
      rooms.add(Room(
        id: docRef.id,
        roomNumber: roomNumber,
        capacity: capacity,
        isLab: isLab,
      ));

      Get.snackbar(
        'Success',
        'Room added successfully',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to add room: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }


  // Fetch Rooms from Firestore
  Future<void> fetchRooms() async {
    try {
      isLoading(true);
      final snapshot = await _firestore.collection('rooms').get();
      rooms.assignAll(
        snapshot.docs.map((doc) => Room.fromFirestore(doc)).toList(),
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to fetch rooms: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }

  // Delete Room from Firestore and local state
  Future<void> deleteRoom(String roomId, int index) async {
    try {
      isLoading(true);
      // Delete room from Firestore
      await _firestore.collection('rooms').doc(roomId).delete();

      // Remove room from local state
      rooms.removeAt(index);
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to delete room: $e',
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      isLoading(false);
    }
  }
}

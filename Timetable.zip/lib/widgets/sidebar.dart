import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidebarx/sidebarx.dart';
import 'package:timetable_management/controllers/auth_controller.dart';

class ExampleSidebarX extends StatelessWidget {
  final AuthController authController = Get.find<AuthController>();
  ExampleSidebarX({
    super.key,
    required SidebarXController controller,
  })  : _controller = controller;

  final SidebarXController _controller;

  @override
  Widget build(BuildContext context) {
    return SidebarX(
      controller: _controller,
      theme: SidebarXTheme(
        hoverTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 16,
        ),
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 6, 92, 178),
          borderRadius: BorderRadius.circular(24),
        ),
        textStyle: const TextStyle(
          color: Colors.white,
          fontSize: 16,
        ),
        selectedTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
        itemTextPadding: const EdgeInsets.only(left: 30),
        selectedItemTextPadding: const EdgeInsets.only(left: 30),
        itemDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.transparent),
        ),
        selectedItemDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white.withOpacity(0.37),
          ),
          gradient: const LinearGradient(
            colors: [Color(0xFF3498DB), Color(0xFF2980B9)],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3498DB).withOpacity(0.3),
              blurRadius: 20,
              spreadRadius: 1,
            )
          ],
        ),
        iconTheme: const IconThemeData(
          color: Colors.white,
          size: 24,
        ),
        selectedIconTheme: const IconThemeData(
          color: Colors.white,
          size: 24,
        ),
      ),
      extendedTheme: const SidebarXTheme(
        width: 270,
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 6, 92, 178),
        ),
      ),
      footerDivider: Divider(
        color: Colors.white.withOpacity(0.3),
        height: 1,
      ),
      footerItems: [
          SidebarXItem(
          icon: Icons.logout,
          label: 'Logout',
          onTap: () => authController.logout(),
          iconWidget: Container(
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.all(8),
            child: const Icon(
              Icons.logout,
              color: Colors.white,
              size: 20,
            ),
          ),
        ),
      ],
      items: const [
        SidebarXItem(
          icon: Icons.dashboard,
          label: 'Dashboard',
        ),
        SidebarXItem(
          icon: Icons.meeting_room,
          label: 'Rooms',
        ),
        SidebarXItem(
          icon: Icons.business,
          label: 'Departments',
        ),
        SidebarXItem(
          icon: Icons.people,
          label: 'Teachers',
        ),
        SidebarXItem(
          icon: Icons.calendar_today,
          label: 'Timetable',
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer();
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          const DrawerHeader(child: Text('Timetable Manager')),
          ListTile(title: const Text('Dashboard'), onTap: () => Navigator.pushReplacementNamed(context, '/dashboard')),
          ListTile(title: const Text('Teachers'), onTap: () => Navigator.pushReplacementNamed(context, '/teachers')),
          ListTile(title: const Text('Rooms'), onTap: () => Navigator.pushReplacementNamed(context, '/rooms')),
          ListTile(title: const Text('Departments'), onTap: () => Navigator.pushReplacementNamed(context, '/departments')),
          ListTile(title: const Text('Semesters'), onTap: () => Navigator.pushReplacementNamed(context, '/semesters')),
          ListTile(title: const Text('Schedule'), onTap: () => Navigator.pushReplacementNamed(context, '/schedule')),
        ],
      ),
    );
  }
}
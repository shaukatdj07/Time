// lib/providers/room_provider.dart
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/room.dart';

class RoomProvider extends ChangeNotifier {
  List<Room> _rooms = [];
  List<Room> get rooms => _rooms;

  RoomProvider() {
    _load();
  }

  Future<void> add(Room r) async {
    _rooms.add(r);
    await _save();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _rooms.removeWhere((r) => r.id == id);
    await _save();
    notifyListeners();
  }

  /* ---------- persistence ---------- */

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('rooms', jsonEncode(_rooms.map((e) => e.toMap()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('rooms');
    if (raw != null) {
      _rooms = (jsonDecode(raw) as List)
          .map((e) => Room.fromMap(e))
          .toList();
    }
    notifyListeners();
  }
}
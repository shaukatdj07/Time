import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService extends ChangeNotifier {
  bool _isLoggedIn = false;

  bool get isLoggedIn => _isLoggedIn;

  AuthService() {
    _restoreLoginState();
  }

  /// Call this after a successful login
  Future<void> login() async {
    _isLoggedIn = true;
    await _persistLoginState();
    notifyListeners();
  }

  /// Logout
  Future<void> logout() async {
    _isLoggedIn = false;
    await _persistLoginState();
    notifyListeners();
  }

  /* ---------- private helpers ---------- */
  static const _keyLogged = 'isLoggedIn';

  Future<void> _persistLoginState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyLogged, _isLoggedIn);
  }

  Future<void> _restoreLoginState() async {
    final prefs = await SharedPreferences.getInstance();
    _isLoggedIn = prefs.getBool(_keyLogged) ?? false;
    notifyListeners();
  }
}
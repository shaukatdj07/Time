import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DbService {
  static const _dbName = 'timetable.db';
  static const _version = 1;
  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final path = join(await getDatabasesPath(), _dbName);
    return openDatabase(path, version: _version, onCreate: _createDB);
  }

  Future<void> _createDB(Database db, int version) async {
    const id = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const text = 'TEXT NOT NULL';
    const integer = 'INTEGER NOT NULL';

    await db.execute('''
      CREATE TABLE teachers (
        id $id,
        name $text,
        email $text UNIQUE
      )''');

    await db.execute('''
      CREATE TABLE rooms (
        id $id,
        name $text UNIQUE
      )''');

    await db.execute('''
      CREATE TABLE departments (
        id $id,
        name $text UNIQUE
      )''');

    await db.execute('''
      CREATE TABLE semesters (
        id $id,
        name $text UNIQUE
      )''');

    await db.execute('''
      CREATE TABLE sections (
        id $id,
        name $text,
        departmentId $integer,
        semesterId $integer,
        FOREIGN KEY(departmentId) REFERENCES departments(id),
        FOREIGN KEY(semesterId)   REFERENCES semesters(id),
        UNIQUE(name, departmentId, semesterId)
      )''');

    await db.execute('''
      CREATE TABLE schedule_entries (
        id $id,
        day          $integer,
        startTime    $text,
        endTime      $text,
        subject      $text,
        teacherId    $integer,
        roomId       $integer,
        sectionId    $integer,
        FOREIGN KEY(teacherId) REFERENCES teachers(id),
        FOREIGN KEY(roomId)    REFERENCES rooms(id),
        FOREIGN KEY(sectionId) REFERENCES sections(id),
        UNIQUE(day, startTime, endTime, roomId),
        UNIQUE(day, startTime, endTime, teacherId),
        UNIQUE(day, startTime, endTime, sectionId)
      )''');
  }

  /* ---------- generic CRUD ---------- */
  Future<int> insert(String table, Map<String, dynamic> row) async =>
      await (await database).insert(table, row);

  Future<List<Map<String, dynamic>>> getAll(String table) async =>
      await (await database).query(table);

  Future<int> delete(String table, int id) async =>
      await (await database).delete(table, where: 'id = ?', whereArgs: [id]);
}
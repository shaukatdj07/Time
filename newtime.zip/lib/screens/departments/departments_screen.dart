import 'package:flutter/material.dart';
import 'package:time/widgets/app_drawer.dart';
import '../../models/department.dart';
import '../../services/db_service.dart';
import 'add_edit_department.dart';

class DepartmentsScreen extends StatefulWidget {
  const DepartmentsScreen({super.key});
  @override
  State<DepartmentsScreen> createState() => _DepartmentsScreenState();
}

class _DepartmentsScreenState extends State<DepartmentsScreen> {
  final _db = DbService();
  late Future<List<Department>> _departments;

  void _refresh() => _departments =
      _db.getAll('departments').then((l) => l.map(Department.fromMap).toList());

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Departments')),
      drawer: const AppDrawer(),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AddEditDepartment()));
          _refresh();
          setState(() {});
        },
      ),
      body: FutureBuilder<List<Department>>(
        future: _departments,
        builder: (_, snap) => snap.hasData
            ? ListView.builder(
            itemCount: snap.data!.length,
            itemBuilder: (_, i) {
              final d = snap.data![i];
              return ListTile(
                title: Text(d.name),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await _db.delete('departments', d.id!);
                    _refresh();
                    setState(() {});
                  },
                ),
              );
            })
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
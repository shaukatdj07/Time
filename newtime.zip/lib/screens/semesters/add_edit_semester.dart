import 'package:flutter/material.dart';
import '../../models/semester.dart';
import '../../services/db_service.dart';

class AddEditSemester extends StatefulWidget {
  const AddEditSemester({super.key});
  @override
  State<AddEditSemester> createState() => _AddEditSemesterState();
}

class _AddEditSemesterState extends State<AddEditSemester> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _db = DbService();

  void _save() async {
    if (!_form.currentState!.validate()) return;
    await _db.insert('semesters', Semester(name: _name.text).toMap());
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Semester')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Semester Name'),
                validator: (v) => v!.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:time/widgets/app_drawer.dart';
import '../../models/semester.dart';
import '../../services/db_service.dart';
import '../sections/sections_screen.dart';
import 'add_edit_semester.dart';

class SemestersScreen extends StatefulWidget {
  const SemestersScreen({super.key});
  @override
  State<SemestersScreen> createState() => _SemestersScreenState();
}

class _SemestersScreenState extends State<SemestersScreen> {
  final _db = DbService();
  late Future<List<Semester>> _semesters;

  void _refresh() =>
      _semesters = _db.getAll('semesters').then((l) => l.map(Semester.fromMap).toList());

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Semesters')),
      drawer: const AppDrawer(),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AddEditSemester()));
          _refresh();
          setState(() {});
        },
      ),
      body: FutureBuilder<List<Semester>>(
        future: _semesters,
        builder: (_, snap) => snap.hasData
            ? ListView.builder(
            itemCount: snap.data!.length,
            itemBuilder: (_, i) {
              final s = snap.data![i];
              return ListTile(
                title: Text(s.name),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => SectionsScreen(semester: s))),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await _db.delete('semesters', s.id!);
                    _refresh();
                    setState(() {});
                  },
                ),
              );
            })
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
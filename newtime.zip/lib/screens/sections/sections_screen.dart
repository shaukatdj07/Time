import 'package:flutter/material.dart';
import '../../models/section.dart';
import '../../models/semester.dart';
import '../../services/db_service.dart';
import 'add_edit_section.dart';

class SectionsScreen extends StatefulWidget {
  final Semester semester;
  const SectionsScreen({super.key, required this.semester});

  @override
  State<SectionsScreen> createState() => _SectionsScreenState();
}

class _SectionsScreenState extends State<SectionsScreen> {
  final _db = DbService();
  late Future<List<Section>> _sections;

  void _refresh() => _sections = _db
      .getAll('sections')
      .then((l) => l.map(Section.fromMap).where((s) => s.semesterId == widget.semester.id).toList());

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sections ‑ ${widget.semester.name}')),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => AddEditSection(semester: widget.semester)));
          _refresh();
          setState(() {});
        },
      ),
      body: FutureBuilder<List<Section>>(
        future: _sections,
        builder: (_, snap) => snap.hasData
            ? ListView.builder(
            itemCount: snap.data!.length,
            itemBuilder: (_, i) {
              final s = snap.data![i];
              return ListTile(
                title: Text(s.name),
                subtitle: FutureBuilder(
                    future: _db.getAll('departments').then(
                            (l) => l.firstWhere((d) => d['id'] == s.departmentId)['name']),
                    builder: (_, snap) => snap.hasData
                        ? Text('Department: ${snap.data}')
                        : const SizedBox.shrink()),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await _db.delete('sections', s.id!);
                    _refresh();
                    setState(() {});
                  },
                ),
              );
            })
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
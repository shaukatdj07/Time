import 'package:flutter/material.dart';
import '../../models/section.dart';
import '../../models/semester.dart';
import '../../services/db_service.dart';

class AddEditSection extends StatefulWidget {
  final Semester semester;
  const AddEditSection({super.key, required this.semester});

  @override
  State<AddEditSection> createState() => _AddEditSectionState();
}

class _AddEditSectionState extends State<AddEditSection> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  int? _deptId;
  List<Map<String, dynamic>> _departments = [];
  final _db = DbService();

  @override
  void initState() {
    super.initState();
    _loadDepts();
  }

  void _loadDepts() async {
    _departments = await _db.getAll('departments');
    setState(() {});
  }

  void _save() async {
    if (!_form.currentState!.validate() || _deptId == null) return;
    await _db.insert(
      'sections',
      Section(
        name: _name.text,
        departmentId: _deptId!,
        semesterId: widget.semester.id!,   // ← cast or use ?? 0
      ).toMap(),
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Section')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Section Name'),
                validator: (v) => v!.trim().isEmpty ? 'Required' : null,
              ),
            DropdownButtonFormField<int>(
              value: _deptId,
              items: _departments
                  .map<DropdownMenuItem<int>>(
                      (d) => DropdownMenuItem<int>(
                    value: d['id'] as int,   // ← cast
                    child: Text(d['name']),
                  ))
                  .toList(),
              onChanged: (v) => setState(() => _deptId = v),
              decoration: const InputDecoration(labelText: 'Department'),
            ),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
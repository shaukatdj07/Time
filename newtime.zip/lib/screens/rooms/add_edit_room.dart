import 'package:flutter/material.dart';
import '../../models/room.dart';
import '../../services/db_service.dart';

class AddEditRoom extends StatefulWidget {
  const AddEditRoom({super.key});
  @override
  State<AddEditRoom> createState() => _AddEditRoomState();
}

class _AddEditRoomState extends State<AddEditRoom> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _db = DbService();

  void _save() async {
    if (!_form.currentState!.validate()) return;
    await _db.insert('rooms', Room(name: _name.text).toMap());
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Room')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Room Name'),
                validator: (v) => v!.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
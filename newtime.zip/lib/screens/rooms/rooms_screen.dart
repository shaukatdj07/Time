import 'package:flutter/material.dart';
import 'package:time/widgets/app_drawer.dart';
import '../../models/room.dart';
import '../../services/db_service.dart';
import 'add_edit_room.dart';

class RoomsScreen extends StatefulWidget {
  const RoomsScreen({super.key});
  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  final _db = DbService();
  late Future<List<Room>> _rooms;

  void _refresh() =>
      _rooms = _db.getAll('rooms').then((l) => l.map(Room.fromMap).toList());

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rooms')),
      drawer: const AppDrawer(),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(
              context, MaterialPageRoute(builder: (_) => const AddEditRoom()));
          _refresh();
          setState(() {});
        },
      ),
      body: FutureBuilder<List<Room>>(
        future: _rooms,
        builder: (_, snap) => snap.hasData
            ? ListView.builder(
            itemCount: snap.data!.length,
            itemBuilder: (_, i) {
              final r = snap.data![i];
              return ListTile(
                title: Text(r.name),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await _db.delete('rooms', r.id!);
                    _refresh();
                    setState(() {});
                  },
                ),
              );
            })
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
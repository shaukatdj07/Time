import '../../models/schedule_entry.dart';
import '../../services/db_service.dart';

class ConflictChecker {
  static Future<List<String>> check(ScheduleEntry e) async {
    final db = await DbService().database;
    final rows = await db.rawQuery('''
      SELECT * FROM schedule_entries
      WHERE day = ? AND (
        (startTime < ? AND endTime > ?) OR
        (startTime < ? AND endTime > ?)
      ) AND (roomId = ? OR teacherId = ? OR sectionId = ?)
    ''', [
      e.day,
      e.endTime,
      e.startTime,
      e.endTime,
      e.startTime,
      e.roomId,
      e.teacherId,
      e.sectionId,
    ]);
    return rows.map((r) {
      final conflict = r['roomId'] == e.roomId
          ? 'Room'
          : r['teacherId'] == e.teacherId
          ? 'Teacher'
          : 'Section';
      return '$conflict already booked ${r['startTime']}-${r['endTime']}';
    }).toList();
  }
}
import 'package:flutter/material.dart';
import '../../models/schedule_entry.dart';
import '../../services/db_service.dart';
import 'conflict_checker.dart';

class AddEditScheduleEntry extends StatefulWidget {
  final int sectionId;
  const AddEditScheduleEntry({super.key, required this.sectionId});

  @override
  State<AddEditScheduleEntry> createState() => _AddEditScheduleEntryState();
}

class _AddEditScheduleEntryState extends State<AddEditScheduleEntry> {
  final _form = GlobalKey<FormState>();
  final _subject = TextEditingController();
  int? _day;
  TimeOfDay? _start, _end;
  int? _teacherId, _roomId;

  final _db = DbService();
  List<Map<String, dynamic>> _teachers = [];
  List<Map<String, dynamic>> _rooms = [];

  @override
  void initState() {
    super.initState();
    _loadTeachers();
    _loadRooms();
  }

  Future<void> _loadTeachers() async =>
      _teachers = await _db.getAll('teachers');

  Future<void> _loadRooms() async =>
      _rooms = await _db.getAll('rooms');

  Future<void> _pickTime(bool start) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        if (start) _start = picked;
        else _end = picked;
      });
    }
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate() ||
        _day == null ||
        _start == null ||
        _end == null ||
        _teacherId == null ||
        _roomId == null) return;

    final entry = ScheduleEntry(
      day: _day!,
      startTime: _start!.format(context),
      endTime: _end!.format(context),
      subject: _subject.text,
      teacherId: _teacherId!,
      roomId: _roomId!,
      sectionId: widget.sectionId,
    );

    final conflicts = await ConflictChecker.check(entry);
    if (conflicts.isNotEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(conflicts.first)));
      }
      return;
    }

    await _db.insert('schedule_entries', entry.toMap());
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Class')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(
                controller: _subject,
                decoration: const InputDecoration(labelText: 'Subject'),
                validator: (v) => v!.trim().isEmpty ? 'Required' : null,
              ),
              DropdownButtonFormField<int>(
                value: _day,
                items: List.generate(7, (i) => i)
                    .map<DropdownMenuItem<int>>((d) => DropdownMenuItem<int>(
                    value: d,
                    child: Text(
                        ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d])))
                    .toList(),
                onChanged: (v) => setState(() => _day = v),
                decoration: const InputDecoration(labelText: 'Day'),
              ),
              ListTile(
                title: Text(_start == null
                    ? 'Pick start time'
                    : 'Start: ${_start!.format(context)}'),
                trailing: const Icon(Icons.access_time),
                onTap: () => _pickTime(true),
              ),
              ListTile(
                title: Text(_end == null
                    ? 'Pick end time'
                    : 'End: ${_end!.format(context)}'),
                trailing: const Icon(Icons.access_time),
                onTap: () => _pickTime(false),
              ),
              DropdownButtonFormField<int>(
                value: _teacherId,
                items: _teachers
                    .map<DropdownMenuItem<int>>(
                        (t) => DropdownMenuItem<int>(
                      value: t['id'] as int,
                      child: Text(t['name']),
                    ))
                    .toList(),
                onChanged: (v) => setState(() => _teacherId = v),
                decoration: const InputDecoration(labelText: 'Teacher'),
              ),
              DropdownButtonFormField<int>(
                value: _roomId,
                items: _rooms
                    .map<DropdownMenuItem<int>>(
                        (r) => DropdownMenuItem<int>(
                      value: r['id'] as int,
                      child: Text(r['name']),
                    ))
                    .toList(),
                onChanged: (v) => setState(() => _roomId = v),
                decoration: const InputDecoration(labelText: 'Room'),
              ),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: _save, child: const Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
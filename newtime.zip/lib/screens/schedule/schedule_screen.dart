import 'package:flutter/material.dart';
import '../../models/semester.dart';
import '../../models/department.dart';
import '../../models/section.dart';
import '../../services/db_service.dart';
import '../../widgets/app_drawer.dart';
import 'add_edit_schedule_entry.dart';

class ScheduleScreen extends StatefulWidget {
  const ScheduleScreen({super.key});
  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  final _db = DbService();
  Department? _dept;
  Semester? _sem;
  Section? _sec;
  List<Department> _depts = [];
  List<Semester> _sems = [];
  List<Section> _secs = [];
  List<Map<String, dynamic>> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadDepts();
  }

  Future<void> _loadDepts() async {
    _depts = (await _db.getAll('departments')).map(Department.fromMap).toList();
    setState(() {});
  }

  Future<void> _loadSems() async {
    if (_dept == null) return;
    _sems = (await _db.getAll('semesters')).map(Semester.fromMap).toList();
    setState(() {});
  }

  Future<void> _loadSecs() async {
    if (_dept == null || _sem == null) return;
    _secs = (await _db.getAll('sections'))
        .map(Section.fromMap)
        .where((s) => s.departmentId == _dept!.id && s.semesterId == _sem!.id)
        .toList();
    setState(() {});
  }

  Future<void> _loadEntries() async {
    if (_sec == null) return;
    _entries = await _db.getAll('schedule_entries')
      ..retainWhere((e) => e['sectionId'] == _sec!.id);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Schedule')),
      drawer: const AppDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            DropdownButton<Department>(
              isExpanded: true,
              value: _dept,
              hint: const Text('Select Department'),
              items: _depts
                  .map((d) => DropdownMenuItem(value: d, child: Text(d.name)))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  _dept = val;
                  _sem = null;
                  _sec = null;
                  _secs.clear();
                  _entries.clear();
                  _loadSems();
                });
              },
            ),
            if (_dept != null)
              DropdownButton<Semester>(
                isExpanded: true,
                value: _sem,
                hint: const Text('Select Semester'),
                items: _sems
                    .map((s) => DropdownMenuItem(value: s, child: Text(s.name)))
                    .toList(),
                onChanged: (val) {
                  setState(() {
                    _sem = val;
                    _sec = null;
                    _entries.clear();
                    _loadSecs();
                  });
                },
              ),
            if (_sem != null)
              DropdownButton<Section>(
                isExpanded: true,
                value: _sec,
                hint: const Text('Select Section'),
                items: _secs
                    .map((s) => DropdownMenuItem(value: s, child: Text(s.name)))
                    .toList(),
                onChanged: (val) {
                  setState(() {
                    _sec = val;
                    _loadEntries();
                  });
                },
              ),
            const SizedBox(height: 8),
            Expanded(
              child: _sec == null
                  ? const Center(child: Text('Choose filters'))
                  : _entries.isEmpty
                  ? const Center(child: Text('No classes'))
                  : ListView.builder(
                itemCount: _entries.length,
                itemBuilder: (_, i) {
                  final e = _entries[i];
                  return ListTile(
                    title: Text(e['subject']),
                    subtitle: Text(
                        '${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][e['day'] as int]} '
                            '${e['startTime']} - ${e['endTime']}'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: _sec == null
          ? null
          : FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final id = _sec?.id;
          if (id == null) return;
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AddEditScheduleEntry(sectionId: id),
            ),
          );
          _loadEntries();
        },
      ),
    );
  }
}
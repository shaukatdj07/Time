import 'package:flutter/material.dart';
import 'package:time/widgets/app_drawer.dart';
import '../../services/db_service.dart';

class DashboardScreen extends StatelessWidget {
  final _db = DbService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      drawer: const AppDrawer(),
      body: FutureBuilder<List<int>>(
        future: Future.wait([
          _db.getAll('teachers').then((l) => l.length),
          _db.getAll('rooms').then((l) => l.length),
          _db.getAll('departments').then((l) => l.length),
        ]),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final [tCount, rCount, dCount] = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _CountCard('Total Teachers', tCount),
              _CountCard('Total Rooms', rCount),
              _CountCard('Total Departments', dCount),
            ],
          );
        },
      ),
    );
  }
}

class _CountCard extends StatelessWidget {
  final String label;
  final int value;
  const _CountCard(this.label, this.value);
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(label),
        trailing: Text('$value', style: const TextStyle(fontSize: 24)),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import '../../models/teacher.dart';
import '../../services/db_service.dart';

class AddEditTeacher extends StatefulWidget {
  const AddEditTeacher();
  @override
  State<AddEditTeacher> createState() => _AddEditTeacherState();
}

class _AddEditTeacherState extends State<AddEditTeacher> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _db = DbService();

  void _save() async {
    if (!_form.currentState!.validate()) return;
    await _db.insert('teachers', Teacher(name: _name.text, email: _email.text).toMap());
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Teacher')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => v!.isEmpty ? 'Required' : null,
              ),
              TextFormField(
                controller: _email,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) => v!.isEmpty ? 'Required' : null,
              ),
              ElevatedButton(onPressed: _save, child: const Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
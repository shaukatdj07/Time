import 'package:flutter/material.dart';
import 'package:time/widgets/app_drawer.dart';
import '../../models/teacher.dart';
import '../../services/db_service.dart';
import 'add_edit_teacher.dart';

class TeachersScreen extends StatefulWidget {
  const TeachersScreen();
  @override
  State<TeachersScreen> createState() => _TeachersScreenState();
}

class _TeachersScreenState extends State<TeachersScreen> {
  final _db = DbService();
  late Future<List<Teacher>> _teachers;

  void _refresh() =>
      _teachers = _db.getAll('teachers').then((l) => l.map(Teacher.fromMap).toList());

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Teachers')),
      drawer: const AppDrawer(),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditTeacher()));
          _refresh();
          setState(() {});
        },
      ),
      body: FutureBuilder<List<Teacher>>(
        future: _teachers,
        builder: (_, snap) => snap.hasData
            ? ListView.builder(
            itemCount: snap.data!.length,
            itemBuilder: (_, i) {
              final t = snap.data![i];
              return ListTile(
                title: Text(t.name),
                subtitle: Text(t.email),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await _db.delete('teachers', t.id!);
                    _refresh();
                    setState(() {});
                  },
                ),
              );
            })
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
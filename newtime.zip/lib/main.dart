import 'package:flutter/material.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/teachers/teachers_screen.dart';
import 'screens/rooms/rooms_screen.dart';
import 'screens/departments/departments_screen.dart';
import 'screens/semesters/semesters_screen.dart';
import 'screens/schedule/schedule_screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Timetable',
      debugShowCheckedModeBanner: false,
      initialRoute: '/dashboard',
      routes: {
        '/dashboard': (_) => DashboardScreen(),
        '/teachers': (_) => const TeachersScreen(),
        '/rooms': (_) => const RoomsScreen(),
        '/departments': (_) => const DepartmentsScreen(),
        '/semesters': (_) => const SemestersScreen(),
        '/schedule': (_) => const ScheduleScreen(),
      },
    );
  }
}
class Section {
  final int? id;
  final String name;
  final int departmentId;
  final int semesterId;

  Section(
      {this.id,
        required this.name,
        required this.departmentId,
        required this.semesterId});

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'departmentId': departmentId,
    'semesterId': semesterId
  };

  static Section fromMap(Map<String, dynamic> map) => Section(
      id: map['id'],
      name: map['name'],
      departmentId: map['departmentId'],
      semesterId: map['semesterId']);
}
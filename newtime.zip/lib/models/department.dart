class Department {
  final int? id;
  final String name;

  Department({this.id, required this.name});

  Map<String, dynamic> toMap() => {'id': id, 'name': name};

  static Department fromMap(Map<String, dynamic> map) =>
      Department(id: map['id'], name: map['name']);
}
class Semester {
  final int? id;
  final String name;

  Semester({this.id, required this.name});

  Map<String, dynamic> toMap() => {'id': id, 'name': name};

  static Semester fromMap(Map<String, dynamic> map) =>
      Semester(id: map['id'], name: map['name']);
}
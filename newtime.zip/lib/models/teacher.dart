class Teacher {
  final int? id;
  final String name;
  final String email;

  Teacher({this.id, required this.name, required this.email});

  Map<String, dynamic> toMap() =>
      {'name': name, 'email': email};

  // ➜  add this factory
  factory Teacher.fromMap(Map<String, dynamic> map) =>
      Teacher(
        id: map['id'] as int?,
        name: map['name'] as String,
        email: map['email'] as String,
      );
}
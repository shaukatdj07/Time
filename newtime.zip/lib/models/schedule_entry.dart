class ScheduleEntry {
  final int? id;
  final int day;
  final String startTime;
  final String endTime;
  final String subject;
  final int teacherId;
  final int roomId;
  final int sectionId;

  ScheduleEntry(
      {this.id,
        required this.day,
        required this.startTime,
        required this.endTime,
        required this.subject,
        required this.teacherId,
        required this.roomId,
        required this.sectionId});

  Map<String, dynamic> toMap() => {
    'id': id,
    'day': day,
    'startTime': startTime,
    'endTime': endTime,
    'subject': subject,
    'teacherId': teacherId,
    'roomId': roomId,
    'sectionId': sectionId
  };

  static ScheduleEntry fromMap(Map<String, dynamic> map) => ScheduleEntry(
      id: map['id'],
      day: map['day'],
      startTime: map['startTime'],
      endTime: map['endTime'],
      subject: map['subject'],
      teacherId: map['teacherId'],
      roomId: map['roomId'],
      sectionId: map['sectionId']);

  String get dayName =>
      ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][day];
}
class Room {
  final int? id;
  final String name;

  Room({this.id, required this.name});

  Map<String, dynamic> toMap() => {'id': id, 'name': name};

  static Room fromMap(Map<String, dynamic> map) =>
      Room(id: map['id'], name: map['name']);
}
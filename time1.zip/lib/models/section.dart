class Section {
  final String id;
  final String name;
  final String semesterId;   // links to a semester

  Section({
    required this.id,
    required this.name,
    required this.semesterId,
  });

  Map<String, dynamic> toMap() =>
      {'id': id, 'name': name, 'semesterId': semesterId};

  factory Section.fromMap(Map<String, dynamic> map) =>
      Section(
        id: map['id'],
        name: map['name'],
        semesterId: map['semesterId'],
      );

  @override
  String toString() => name;
}
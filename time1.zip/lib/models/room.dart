// lib/models/room.dart
class Room {
  final String id;
  final String name;

  Room({required this.id, required this.name});

  Map<String, dynamic> toMap() => {'id': id, 'name': name};

  factory Room.fromMap(Map<String, dynamic> map) =>
      Room(id: map['id'], name: map['name']);

  @override
  String toString() => name;
}
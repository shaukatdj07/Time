// lib/models/teacher.dart
class Teacher {
  final String id;
  final String name;
  final String? departmentId;   // nullable
  final String? email;          // nullable
  final int? age;               // nullable int

  Teacher({
    required this.id,
    required this.name,
    this.departmentId,
    this.email,
    this.age,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'departmentId': departmentId,
    'email': email,
    'age': age,
  };

  factory Teacher.fromMap(Map<String, dynamic> map) => Teacher(
    id: map['id'],
    name: map['name'],
    departmentId: map['departmentId'],
    email: map['email'],
    age: map['age'],
  );

  @override
  String toString() => name;
}
// lib/models/semester.dart
class Semester {
  final String id;
  final String name;

  Semester({required this.id, required this.name});

  Map<String, dynamic> toMap() => {'id': id, 'name': name};
  factory Semester.fromMap(Map<String, dynamic> map) =>
      Semester(id: map['id'], name: map['name']);
  @override
  String toString() => name;
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/department_provider.dart';
import '../providers/teacher_provider.dart';
import '../providers/room_provider.dart';

class ScheduleCreationScreen extends StatelessWidget {
  const ScheduleCreationScreen({super.key});

  static Route route(BuildContext context) => MaterialPageRoute(
    builder: (_) => MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: context.read<DepartmentProvider>()),
        ChangeNotifierProvider.value(value: context.read<TeacherProvider>()),
        ChangeNotifierProvider.value(value: context.read<RoomProvider>()),
      ],
      child: const ScheduleCreationScreen(),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Schedule')),
      body: const Center(child: Text('Scheduling UI will go here')),
    );
  }
}
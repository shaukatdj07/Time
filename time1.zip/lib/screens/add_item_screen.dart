import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/department.dart';
import '../models/teacher.dart';
import '../models/room.dart';
import '../models/semester.dart';
import '../models/section.dart';
import '../providers/department_provider.dart';
import '../providers/teacher_provider.dart';
import '../providers/room_provider.dart';
import '../providers/semester_provider.dart';
import '../providers/section_provider.dart';

class AddItemScreen extends StatefulWidget {
  const AddItemScreen({super.key});

  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  final _controller = TextEditingController();
  String _selectedType = 'Department';
  String? _selectedSemesterId; // only used when type == Section

  @override
  Widget build(BuildContext context) {
    final semesters = context.watch<SemesterProvider>().semesters;

    return Scaffold(
      appBar: AppBar(title: const Text('Add New Item')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButton<String>(
              value: _selectedType,
              isExpanded: true,
              items: ['Department', 'Teacher', 'Room', 'Semester', 'Section']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (val) => setState(() {
                _selectedType = val!;
                _selectedSemesterId = null; // reset when type changes
              }),
            ),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(labelText: 'Name'),
            ),

            // only show semester picker for "Section"
            if (_selectedType == 'Section') ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedSemesterId,
                hint: const Text('Select Semester'),
                items: semesters
                    .map((e) => DropdownMenuItem(
                  value: e.id,
                  child: Text(e.name),
                ))
                    .toList(),
                onChanged: (val) => setState(() => _selectedSemesterId = val),
                validator: (val) =>
                val == null ? 'Choose a semester' : null,
              ),
            ],

            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _canSave ? _save : null,
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  bool get _canSave {
    if (_controller.text.trim().isEmpty) return false;
    if (_selectedType == 'Section' && _selectedSemesterId == null) return false;
    return true;
  }

  void _save() {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final name = _controller.text.trim();

    switch (_selectedType) {
      case 'Department':
        context.read<DepartmentProvider>().add(Department(id: id, name: name));
        break;
      case 'Teacher':
        context.read<TeacherProvider>().add(Teacher(id: id, name: name));
        break;
      case 'Room':
        context.read<RoomProvider>().add(Room(id: id, name: name));
        break;
      case 'Semester':
        context.read<SemesterProvider>().add(Semester(id: id, name: name));
        break;
      case 'Section':
        context.read<SectionProvider>().add(
          Section(
            id: id,
            name: name,
            semesterId: _selectedSemesterId!,
          ),
        );
        break;
    }
    Navigator.pop(context);
  }
}
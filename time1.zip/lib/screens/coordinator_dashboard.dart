import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/semester.dart';           // <-- import the model
import '../providers/department_provider.dart';
import '../providers/teacher_provider.dart';
import '../providers/room_provider.dart';
import '../providers/semester_provider.dart';
import '../providers/section_provider.dart';
import 'add_item_screen.dart';

class CoordinatorDashboard extends StatelessWidget {
  const CoordinatorDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final semesters = context.watch<SemesterProvider>().semesters;

    return Scaffold(
      appBar: AppBar(title: const Text('Coordinator Dashboard')),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: [
          _buildCard('Departments',
              context.watch<DepartmentProvider>().departments, Icons.school),
          _buildCard('Teachers',
              context.watch<TeacherProvider>().teachers, Icons.person),
          _buildCard('Rooms',
              context.watch<RoomProvider>().rooms, Icons.meeting_room),
          const Divider(height: 32),
          ...semesters.map((sem) => _semesterTile(context, sem)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AddItemScreen())),
        child: const Icon(Icons.add),
      ),
      persistentFooterButtons: [
        ElevatedButton(
          onPressed: () => _showNoPermission(context),
          child: const Text('Create Class Schedule'),
        ),
      ],
    );
  }

  Widget _semesterTile(BuildContext context, Semester sem) {
    final sections =
    Provider.of<SectionProvider>(context, listen: false).forSemester(sem.id);
    return ExpansionTile(
      title: Text(sem.name,
          style: const TextStyle(fontWeight: FontWeight.bold)),
      children: sections.isEmpty
          ? const [
        Padding(
          padding: EdgeInsets.only(left: 24, bottom: 8),
          child: Text('No sections added'),
        )
      ]
          : sections
          .map((s) => ListTile(
        dense: true,
        title: Text('  • ${s.name}'),
      ))
          .toList(),
    );
  }

  Widget _buildCard(String title, List items, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon),
              const SizedBox(width: 6),
              Text(title,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold))
            ]),
            items.isEmpty
                ? const Text('No items')
                : Column(
                children: items
                    .map((e) => ListTile(title: Text(e.toString())))
                    .toList()),
          ],
        ),
      ),
    );
  }

  void _showNoPermission(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Scheduling is disabled for coordinators.'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/teacher.dart';

class TeacherProvider extends ChangeNotifier {
  List<Teacher> _teachers = [];
  List<Teacher> get teachers => _teachers;

  TeacherProvider() { _load(); }

  Future<void> add(Teacher t) async {
    _teachers.add(t);
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('teachers', jsonEncode(_teachers.map((e) => e.toMap()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('teachers');
    if (raw != null) {
      _teachers = (jsonDecode(raw) as List).map((e) => Teacher.fromMap(e)).toList();
    }
    notifyListeners();
  }
}
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/semester.dart';

class SemesterProvider extends ChangeNotifier {
  List<Semester> _semesters = [];
  List<Semester> get semesters => _semesters;

  SemesterProvider() {
    _load();
  }

  Future<void> add(Semester s) async {
    _semesters.add(s);
    await _save();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _semesters.removeWhere((s) => s.id == id);
    await _save();
    notifyListeners();
  }

  /* ---------- persistence ---------- */
  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('semesters', jsonEncode(_semesters.map((e) => e.toMap()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('semesters');
    if (raw != null) {
      _semesters = (jsonDecode(raw) as List)
          .map((e) => Semester.fromMap(e))
          .toList();
    }
    notifyListeners();
  }
}
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/section.dart';

class SectionProvider extends ChangeNotifier {
  List<Section> _sections = [];
  List<Section> get sections => _sections;

  SectionProvider() {
    _load();
  }

  /* ── ADD only ── no remove() ── */
  Future<void> add(Section s) async {
    _sections.add(s);
    await _save();
    notifyListeners();
  }

  /* ── persistence ── */
  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('sections', jsonEncode(_sections.map((e) => e.toMap()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('sections');
    if (raw != null) {
      _sections = (jsonDecode(raw) as List)
          .map((e) => Section.fromMap(e))
          .toList();
    }
    notifyListeners();
  }

  /* helper: sections for one semester */
  List<Section> forSemester(String semesterId) =>
      _sections.where((s) => s.semesterId == semesterId).toList();
}
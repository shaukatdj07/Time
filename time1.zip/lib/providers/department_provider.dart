import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/department.dart';

class DepartmentProvider extends ChangeNotifier {
  List<Department> _departments = [];
  List<Department> get departments => _departments;

  DepartmentProvider() {
    _load();
  }

  Future<void> add(Department d) async {
    _departments.add(d);
    await _save();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _departments.removeWhere((e) => e.id == id);
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('departments', jsonEncode(_departments.map((e) => e.toMap()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('departments');
    if (raw != null) {
      _departments = (jsonDecode(raw) as List)
          .map((e) => Department.fromMap(e))
          .toList();
    }
    notifyListeners();
  }
}